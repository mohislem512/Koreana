# Koreana
Flutter app (Android). Build: see tool/build.sh. Backend (accounts rules, payments): backend/.
