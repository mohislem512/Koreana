const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
const Stripe = require('stripe');
admin.initializeApp();

const STRIPE_KEY = defineSecret('STRIPE_KEY');
const STRIPE_WHSEC = defineSecret('STRIPE_WHSEC');

// Prices live ONLY here (server side) so the app can never change them.
const PLANS = { 1: { cents: 1000, months: 1 }, 2: { cents: 1600, months: 2 }, 3: { cents: 2500, months: 3 } };

exports.createCheckout = onRequest({ secrets: [STRIPE_KEY], cors: true }, async (req, res) => {
  try {
    const token = (req.get('Authorization') || '').replace('Bearer ', '');
    const user = await admin.auth().verifyIdToken(token);
    if (!user.email_verified) return res.status(403).json({ error: 'verify_email' });
    const plan = PLANS[req.body && req.body.plan];
    if (!plan) return res.status(400).json({ error: 'bad_plan' });
    const stripe = new Stripe(STRIPE_KEY.value());
    const host = `https://${process.env.GCLOUD_PROJECT}.web.app`;
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      customer_email: user.email,
      client_reference_id: user.uid,
      line_items: [{
        quantity: 1,
        price_data: { currency: 'usd', unit_amount: plan.cents, product_data: { name: `Koreana Premium - ${plan.months} month(s)` } },
      }],
      metadata: { uid: user.uid, months: String(plan.months) },
      success_url: `${host}/paid.html`,
      cancel_url: `${host}/cancel.html`,
    });
    res.json({ url: session.url });
  } catch (e) {
    res.status(401).json({ error: 'unauthorized' });
  }
});

exports.stripeWebhook = onRequest({ secrets: [STRIPE_KEY, STRIPE_WHSEC] }, async (req, res) => {
  const stripe = new Stripe(STRIPE_KEY.value());
  let ev;
  try {
    ev = stripe.webhooks.constructEvent(req.rawBody, req.get('stripe-signature'), STRIPE_WHSEC.value());
  } catch (e) {
    return res.status(400).send('bad signature');
  }
  if (ev.type === 'checkout.session.completed' && ev.data.object.payment_status === 'paid') {
    const s = ev.data.object;
    const uid = s.metadata.uid;
    const months = parseInt(s.metadata.months, 10);
    const ref = admin.firestore().doc(`entitlements/${uid}`);
    await admin.firestore().runTransaction(async (t) => {
      const d = await t.get(ref);
      const data = d.exists ? d.data() : {};
      if ((data.processed || []).includes(s.id)) return; // idempotent
      const cur = data.until ? data.until.toMillis() : 0;
      const base = Math.max(Date.now(), cur);
      t.set(ref, {
        until: admin.firestore.Timestamp.fromMillis(base + months * 30 * 86400000),
        verified: true,
        processed: admin.firestore.FieldValue.arrayUnion(s.id),
      }, { merge: true });
    });
  }
  res.json({ received: true });
});
