// Paste your Firebase project values here to enable cloud accounts
// (sync progress across devices). Leave as-is for local accounts.
const kApiKey = 'PASTE_API_KEY';
const kProjectId = 'PASTE_PROJECT_ID';
// URL of your deployed Cloud Function "createCheckout" (see backend/README).
const kCheckoutEndpoint = 'PASTE_CHECKOUT_URL';
