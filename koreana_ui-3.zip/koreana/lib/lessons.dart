import 'data.dart';

class Lesson {
  final List<String> title, body;
  final List<W> ex;
  const Lesson(this.title, this.body, this.ex);
}

const lessons = <List<Lesson>>[
  [
    Lesson(['الحروف الكورية (한글)', 'Hangul basics', 'Bases du hangeul'], [
      'الهانغول فيه 14 حرفا ساكنا و10 حروف علة أساسية. ㅏ = a ، ㅣ = i ، ㅗ = o ، ㅜ = u ، ㄱ = g/k ، ㄴ = n ، ㅁ = m. تُجمع الحروف في مقاطع مثل 나 (na) و 마 (ma).',
      'Hangul has 14 basic consonants and 10 basic vowels. ㅏ = a, ㅣ = i, ㅗ = o, ㅜ = u, ㄱ = g/k, ㄴ = n, ㅁ = m. Letters combine into blocks like 나 (na) and 마 (ma).',
      'Le hangeul compte 14 consonnes et 10 voyelles de base. ㅏ = a, ㅣ = i, ㅗ = o, ㅜ = u, ㄱ = g/k, ㄴ = n, ㅁ = m. Les lettres forment des blocs comme 나 (na) et 마 (ma).'
    ], [
      W('나', 'na', 'أنا (غير رسمي)', 'I / me (casual)', 'moi (familier)'),
      W('아이', 'ai', 'طفل', 'Child', 'Enfant'),
      W('우유', 'uyu', 'حليب', 'Milk', 'Lait'),
    ]),
    Lesson(['الأدب في الكلام (요)', 'Polite endings (요)', 'Politesse (요)'], [
      'إضافة 요 في نهاية الجملة تجعلها مهذبة، وهي الصيغة المناسبة للحياة اليومية. مثال: 주세요 = من فضلك أعطني.',
      'Adding 요 to the end of a sentence makes it polite — the standard style for daily life. Example: 주세요 = please give me.',
      'Ajouter 요 en fin de phrase la rend polie : c’est le registre courant. Exemple : 주세요 = donnez-moi, s’il vous plaît.'
    ], [
      W('물 주세요', 'mul juseyo', 'ماء من فضلك', 'Water, please', 'De l’eau, s’il vous plaît'),
      W('좋아요', 'joayo', 'جيد / أحب', 'Good / I like it', 'Bien / j’aime'),
    ]),
  ],
  [
    Lesson(['فعل الكينونة 이에요/예요', 'To be: 이에요/예요', 'Être : 이에요/예요'], [
      'نضيف 이에요 بعد اسم ينتهي بحرف ساكن، و 예요 بعد اسم ينتهي بحرف علة. 학생이에요 = أنا/هو طالب، 의사예요 = طبيب.',
      'Add 이에요 after a noun ending in a consonant and 예요 after a vowel. 학생이에요 = (I am) a student, 의사예요 = a doctor.',
      'On ajoute 이에요 après une consonne et 예요 après une voyelle. 학생이에요 = (je suis) étudiant, 의사예요 = médecin.'
    ], [
      W('학생이에요', 'haksaengieyo', 'طالب', 'a student', 'étudiant'),
      W('의사예요', 'uisayeyo', 'طبيب', 'a doctor', 'médecin'),
    ]),
    Lesson(['الأرقام', 'Numbers', 'Les nombres'], [
      'للعدّ نستخدم 하나 둘 셋ـ(للأشياء)، وللتواريخ والأسعار 일 이 삼.',
      'Native numbers 하나, 둘, 셋 count objects; Sino numbers 일, 이, 삼 are for dates and prices.',
      'Les nombres natifs 하나, 둘, 셋 comptent les objets ; les nombres sino-coréens 일, 이, 삼 servent aux dates et aux prix.'
    ], [
      W('일', 'il', 'واحد (أسعار/تواريخ)', 'one (dates/prices)', 'un (dates/prix)'),
      W('이', 'i', 'اثنان', 'two', 'deux'),
      W('삼', 'sam', 'ثلاثة', 'three', 'trois'),
    ]),
  ],
  [
    Lesson(['أدوات الموضوع والفاعل 은/는 · 이/가', 'Particles 은/는 and 이/가', 'Particules 은/는 et 이/가'], [
      '은/는 تحدد الموضوع، و이/가 تحدد الفاعل. 은 و이 بعد حرف ساكن، و는 و가 بعد حرف علة.',
      '은/는 marks the topic and 이/가 marks the subject. 은 and 이 follow a consonant; 는 and 가 follow a vowel.',
      '은/는 marque le thème et 이/가 le sujet. 은 et 이 après une consonne ; 는 et 가 après une voyelle.'
    ], [
      W('저는 학생이에요.', 'jeoneun haksaengieyo', 'أنا طالب.', 'I am a student.', 'Je suis étudiant.'),
      W('비가 와요.', 'biga wayo', 'تمطر.', 'It rains.', 'Il pleut.'),
    ]),
    Lesson(['الماضي ـ았/었어요', 'Past tense -았/었어요', 'Passé -았/었어요'], [
      'للماضي: جذر الفعل + 았어요 إذا كان آخر حرف علة فيه ㅏ أو ㅗ، وإلا + 었어요.',
      'Past tense: verb stem + 았어요 if the last vowel is ㅏ or ㅗ, otherwise + 었어요.',
      'Passé : radical + 았어요 si la dernière voyelle est ㅏ ou ㅗ, sinon + 었어요.'
    ], [
      W('먹었어요', 'meogeosseoyo', 'أكلت', 'I ate', 'J’ai mangé'),
      W('갔어요', 'gasseoyo', 'ذهبت', 'I went', 'Je suis allé'),
    ]),
  ],
  [
    Lesson(['التعبير عن الرغبة ـ고 싶어요', 'Wanting: -고 싶어요', 'Vouloir : -고 싶어요'], [
      'جذر الفعل + 고 싶어요 = أريد أن... مثال: 가고 싶어요 = أريد الذهاب.',
      'Verb stem + 고 싶어요 = I want to... Example: 가고 싶어요 = I want to go.',
      'Radical + 고 싶어요 = je veux... Exemple : 가고 싶어요 = je veux y aller.'
    ], [
      W('가고 싶어요', 'gago sipeoyo', 'أريد الذهاب', 'I want to go', 'Je veux y aller'),
      W('먹고 싶어요', 'meokgo sipeoyo', 'أريد أن آكل', 'I want to eat', 'Je veux manger'),
    ]),
    Lesson(['المستقبل ـ(으)ㄹ 거예요', 'Future: -(으)ㄹ 거예요', 'Futur : -(으)ㄹ 거예요'], [
      'للمستقبل: الجذر + ㄹ 거예요 بعد حرف علة، و 을 거예요 بعد حرف ساكن.',
      'Future: stem + ㄹ 거예요 after a vowel, 을 거예요 after a consonant.',
      'Futur : radical + ㄹ 거예요 après voyelle, 을 거예요 après consonne.'
    ], [
      W('갈 거예요', 'gal geoyeyo', 'سأذهب', 'I will go', 'J’irai'),
      W('먹을 거예요', 'meogeul geoyeyo', 'سآكل', 'I will eat', 'Je mangerai'),
    ]),
  ],
  [
    Lesson(['صيغة الاحترام ـ(으)시', 'Honorific -(으)시-', 'Honorifique -(으)시-'], [
      'لاحترام الأكبر سنا نضيف 시 بعد جذر الفعل: 오다 ← 오세요، 가다 ← 가세요.',
      'To honor someone senior, insert 시 after the verb stem: 오다 → 오세요, 가다 → 가세요.',
      'Pour respecter un aîné, insérez 시 après le radical : 오다 → 오세요, 가다 → 가세요.'
    ], [
      W('선생님이 오세요.', 'seonsaengnimi oseyo', 'المعلم قادم.', 'The teacher is coming.', 'Le professeur arrive.'),
    ]),
    Lesson(['الكلام المنقول ـ다고 해요', 'Reported speech -다고 해요', 'Discours rapporté -다고 해요'], [
      'لنقل كلام الغير: الجملة + 다고 해요 = يقولون إن... مثال: 비가 온다고 해요 = يقولون إنها ستمطر.',
      'To report speech: clause + 다고 해요 = they say that... Example: 비가 온다고 해요 = they say it will rain.',
      'Pour rapporter : proposition + 다고 해요 = on dit que... Exemple : 비가 온다고 해요 = on dit qu’il va pleuvoir.'
    ], [
      W('비가 온다고 해요.', 'biga ondago haeyo', 'يقولون إنها ستمطر.', 'They say it will rain.', 'On dit qu’il va pleuvoir.'),
    ]),
  ],
];
