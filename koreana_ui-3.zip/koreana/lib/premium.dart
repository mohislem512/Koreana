import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'auth.dart';
import 'i18n.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});
  @override
  State<PaywallScreen> createState() => _PwS();
}

class _PwS extends State<PaywallScreen> with WidgetsBindingObserver {
  int plan = 1;
  String msg = '';
  bool busy = false, needVerify = false;
  static const prices = {1: ['\$10', '\$10'], 2: ['\$16', '\$8'], 3: ['\$25', '\$8.33']};
  static const saves = {1: '', 2: '-20%', 3: '-17%'};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) AppState.i.refreshPremium();
  }

  Future<void> _pay() async {
    if (!Auth.cloud) return setState(() => msg = t('cloudNeed'));
    if (!Auth.payReady) return setState(() => msg = t('payOff'));
    setState(() { busy = true; msg = ''; needVerify = false; });
    try {
      if (!await Auth.refreshVerified()) {
        setState(() { needVerify = true; msg = t('verifyFirst'); });
        return;
      }
      final url = await Auth.checkoutUrl(plan);
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } on AuthError catch (e) {
      setState(() => msg = e.msg);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('premium'))),
        body: Watch((_) => ListView(padding: const EdgeInsets.all(18), children: [
              const Icon(Icons.workspace_premium, size: 64, color: KColors.gold),
              const SizedBox(height: 8),
              Text(t('lock'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(t('perks'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 18),
              if (AppState.i.premium)
                KCard(child: Text('✅ ${t('verified')} · ${t('until')} ${AppState.i.until!.toLocal().toString().substring(0, 10)}', textAlign: TextAlign.center, style: const TextStyle(color: KColors.gold, fontWeight: FontWeight.w700))),
              for (final p in [1, 2, 3])
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    onTap: () => setState(() => plan = p),
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: KColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: plan == p ? KColors.primary : Colors.white12, width: 2)),
                      child: Row(children: [
                        Icon(plan == p ? Icons.radio_button_checked : Icons.radio_button_off, color: KColors.primary),
                        const SizedBox(width: 10),
                        Expanded(child: Text(t('plan$p'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
                        if (saves[p]!.isNotEmpty) Container(margin: const EdgeInsetsDirectional.only(end: 8), padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: KColors.green, borderRadius: BorderRadius.circular(10)), child: Text(saves[p]!, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800))),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text(prices[p]![0], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                          Text('${prices[p]![1]}${t('perMonth')}', style: const TextStyle(fontSize: 11, color: Colors.white60)),
                        ]),
                      ]),
                    ),
                  ),
                ),
              const SizedBox(height: 6),
              GradientButton(busy ? '...' : '🔒 ${t('pay')}', busy ? null : _pay),
              if (msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: KColors.orange))),
              if (needVerify) TextButton(onPressed: () async { try { await Auth.sendVerify(); } catch (_) {} }, child: Text(t('verifyBtn'))),
              TextButton(onPressed: AppState.i.refreshPremium, child: Text(t('check'))),
              const SizedBox(height: 6),
              Text(t('payNote'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ])),
      );
}

class FeedbackScreen extends StatefulWidget {
  final int level;
  final bool thenPaywall;
  const FeedbackScreen({super.key, required this.level, this.thenPaywall = false});
  @override
  State<FeedbackScreen> createState() => _FbS();
}

class _FbS extends State<FeedbackScreen> {
  int rating = 5;
  final text = TextEditingController(), wish = TextEditingController();
  String msg = '';
  bool busy = false;

  void _close() {
    if (widget.thenPaywall) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const PaywallScreen()));
    } else {
      Navigator.pop(context);
    }
  }

  Future<void> _send() async {
    if (!Auth.cloud) return setState(() => msg = t('cloudNeed'));
    setState(() => busy = true);
    try {
      await Auth.feedback({
        'uid': Auth.user!.uid,
        'level': widget.level,
        'rating': rating,
        'text': text.text.trim(),
        'wish': wish.text.trim(),
        'lang': '$gLang',
        'ts': DateTime.now().millisecondsSinceEpoch,
      });
      if (!mounted) return;
      AppState.i.msgKey.currentState?.showSnackBar(SnackBar(content: Text(t('thanks'))));
      _close();
    } on AuthError catch (e) {
      setState(() => msg = e.msg);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    InputDecoration d(String l) => InputDecoration(labelText: l, filled: true, fillColor: KColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)));
    return Scaffold(
      appBar: AppBar(title: Text(t('feedback')), leading: IconButton(icon: const Icon(Icons.close), onPressed: _close)),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text('${t('lv${widget.level}')}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        const SizedBox(height: 6),
        Text(t('fbLevel'), textAlign: TextAlign.center),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (var i = 1; i <= 5; i++) IconButton(iconSize: 36, onPressed: () => setState(() => rating = i), icon: Icon(i <= rating ? Icons.star : Icons.star_border, color: KColors.gold)),
        ]),
        const SizedBox(height: 10),
        TextField(controller: text, maxLines: 3, maxLength: 800, decoration: d(t('fbText'))),
        const SizedBox(height: 10),
        TextField(controller: wish, maxLines: 3, maxLength: 800, decoration: d(t('fbWish'))),
        if (msg.isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: KColors.orange))),
        const SizedBox(height: 8),
        GradientButton(busy ? '...' : t('send'), busy ? null : _send),
      ]),
    );
  }
}
