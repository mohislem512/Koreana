import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class KColors {
  static const bg = Color(0xFF0B1030);
  static const surface = Color(0xE6151B45);
  static const primary = Color(0xFF7C6CF7);
  static const blue = Color(0xFF3B82F6);
  static const gold = Color(0xFFF5B83D);
  static const green = Color(0xFF3DBE7A);
  static const orange = Color(0xFFFF8A4C);
  static const grad = LinearGradient(colors: [Color(0xFF6C5CE7), Color(0xFF4F8DF7)]);
}

class KTheme {
  static ThemeData build() {
    final base = ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: KColors.primary, brightness: Brightness.dark),
      scaffoldBackgroundColor: Colors.transparent,
      cardColor: KColors.surface,
    );
    return base.copyWith(
      textTheme: GoogleFonts.cairoTextTheme(base.textTheme),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0, centerTitle: true),
      navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xE60B1030)),
    );
  }
}
