import 'dart:math';
import 'package:flutter/material.dart';
import 'state.dart';
import 'theme.dart';

class Watch extends StatelessWidget {
  final Widget Function(BuildContext) b;
  const Watch(this.b, {super.key});
  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: AppState.i, builder: (ctx, _) => b(ctx));
}

class GradientButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  const GradientButton(this.label, this.onTap, {super.key});
  @override
  Widget build(BuildContext context) => Opacity(
        opacity: onTap == null ? .5 : 1,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            height: 54,
            alignment: Alignment.center,
            decoration: BoxDecoration(gradient: KColors.grad, borderRadius: BorderRadius.circular(18)),
            child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
          ),
        ),
      );
}

class KCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  const KCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.color});
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(color: color ?? KColors.surface, borderRadius: BorderRadius.circular(20)),
        child: child,
      );
}

class KProgress extends StatelessWidget {
  final double value;
  const KProgress(this.value, {super.key});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: LinearProgressIndicator(value: value.clamp(0, 1).toDouble(), minHeight: 8, backgroundColor: Colors.white12, color: KColors.green),
      );
}

class Opt extends StatelessWidget {
  final String label;
  final int state; // 0 neutral, 1 correct, 2 wrong
  final VoidCallback onTap;
  const Opt(this.label, this.state, this.onTap, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: state == 1 ? KColors.green.withOpacity(.85) : state == 2 ? Colors.redAccent.withOpacity(.85) : KColors.surface,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ),
      );
}

class Logo extends StatelessWidget {
  final double size;
  const Logo(this.size, {super.key});
  @override
  Widget build(BuildContext context) => Image.asset('assets/logo.png', width: size, height: size);
}

// ---------- Korean scenery backgrounds (one per level) ----------
class KBackground extends StatelessWidget {
  final int level;
  const KBackground(this.level, {super.key});
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 900),
          child: SizedBox.expand(key: ValueKey(level), child: CustomPaint(painter: ScenePainter(level))),
        ),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withOpacity(.2), Colors.black.withOpacity(.62)]),
          ),
        ),
      ]);
}

class ScenePainter extends CustomPainter {
  final int s;
  ScenePainter(this.s);
  static const skies = [
    [Color(0xFF1B1F5E), Color(0xFFE0668C), Color(0xFFFFB27A)],
    [Color(0xFF2A1B54), Color(0xFFD9534F), Color(0xFFFFC46B)],
    [Color(0xFF0E3B6E), Color(0xFF3FA7D6), Color(0xFFFFE3A3)],
    [Color(0xFF050A24), Color(0xFF14246B), Color(0xFF3B2C7A)],
    [Color(0xFF16313F), Color(0xFF5E8A99), Color(0xFFDCE8E4)],
  ];

  void ridge(Canvas c, Size z, double base, double amp, double seed, Color col) {
    final p = Path()..moveTo(0, z.height);
    for (double x = 0; x <= z.width + 8; x += 8) {
      p.lineTo(x, base - amp * (sin(x * .008 + seed) + .5 * sin(x * .021 + seed * 2) + 1.5) / 3);
    }
    p..lineTo(z.width, z.height)..close();
    c.drawPath(p, Paint()..color = col);
  }

  void roof(Canvas c, double cx, double y, double hw, double hh, Color col) {
    final p = Path()
      ..moveTo(cx - hw - 22, y - 14)
      ..quadraticBezierTo(cx - hw + 6, y + 6, cx - hw * .75, y)
      ..lineTo(cx - hw * .35, y - hh)
      ..lineTo(cx + hw * .35, y - hh)
      ..lineTo(cx + hw * .75, y)
      ..quadraticBezierTo(cx + hw - 6, y + 6, cx + hw + 22, y - 14)
      ..quadraticBezierTo(cx, y + 16, cx - hw - 22, y - 14)
      ..close();
    c.drawPath(p, Paint()..color = col);
  }

  @override
  void paint(Canvas c, Size z) {
    final w = z.width, h = z.height, col = skies[s];
    final rnd = Random(s + 3);
    c.drawRect(Offset.zero & z, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: col).createShader(Offset.zero & z));
    if (s == 3) {
      for (var i = 0; i < 60; i++) {
        c.drawCircle(Offset(rnd.nextDouble() * w, rnd.nextDouble() * h * .5), 1.2, Paint()..color = Colors.white70);
      }
    }
    c.drawCircle(Offset(w * .74, h * (s == 2 ? .5 : .3)), w * .09, Paint()..color = (s == 3 ? const Color(0xFFEDEBFF) : const Color(0xFFFFF1C9)).withOpacity(.92));
    final dark = Color.lerp(col[0], Colors.black, .55)!;
    final ink = Color.lerp(col[0], Colors.black, .75)!;
    switch (s) {
      case 0:
        {
        ridge(c, z, h * .68, h * .12, 1, dark.withOpacity(.7));
        final cx = w * .3;
        c.drawRect(Rect.fromLTWH(cx - 4, h * .40, 8, h * .32), Paint()..color = ink);
        c.drawOval(Rect.fromCenter(center: Offset(cx, h * .42), width: 38, height: 14), Paint()..color = ink);
        c.drawLine(Offset(cx, h * .35), Offset(cx, h * .41), Paint()..color = ink..strokeWidth = 2);
        for (double x = 0; x < w; x += 22) {
          final bh = 30 + rnd.nextDouble() * 80;
          c.drawRect(Rect.fromLTWH(x, h * .74 - bh, 20, bh + h), Paint()..color = ink);
        }
        c.drawLine(Offset(w, h * .08), Offset(w * .5, h * .2), Paint()..color = const Color(0xFF3B2A2A)..strokeWidth = 6);
        for (var i = 0; i < 110; i++) {
          final tt = rnd.nextDouble();
          c.drawCircle(Offset(w * .5 + tt * w * .5, h * .2 - tt * h * .12 + (rnd.nextDouble() - .5) * h * .13), 5 + rnd.nextDouble() * 9,
              Paint()..color = Color.lerp(const Color(0xFFFFC1D6), const Color(0xFFFF8FB1), rnd.nextDouble())!.withOpacity(.8));
        }
        }
        break;
      case 1:
        {
        ridge(c, z, h * .62, h * .16, 2, dark.withOpacity(.75));
        ridge(c, z, h * .74, h * .06, 5, ink);
        final px = w * .5;
        c.drawRect(Rect.fromLTWH(0, h * .8, w, h), Paint()..color = ink);
        c.drawRect(Rect.fromLTWH(px - w * .3, h * .7, w * .6, h * .1), Paint()..color = const Color(0xFF7A2430));
        roof(c, px, h * .7, w * .34, h * .05, const Color(0xFF1E2A3A));
        c.drawRect(Rect.fromLTWH(px - w * .17, h * .62, w * .34, h * .05), Paint()..color = const Color(0xFF7A2430));
        roof(c, px, h * .62, w * .2, h * .06, const Color(0xFF1E2A3A));
        }
        break;
      case 2:
        {
        ridge(c, z, h * .66, h * .3, 4, dark.withOpacity(.9));
        c.drawRect(Rect.fromLTWH(0, h * .66, w, h), Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF2F8FC8), Color(0xFF0B3A63)]).createShader(Rect.fromLTWH(0, h * .66, w, h * .34)));
        for (var i = 0; i < 16; i++) {
          final y = h * .68 + i * h * .02, x = rnd.nextDouble() * w, l = 30 + rnd.nextDouble() * 70;
          c.drawLine(Offset(x, y), Offset(x + l, y), Paint()..color = Colors.white24..strokeWidth = 2);
        }
        c.drawRect(Rect.fromLTWH(w * .72, h * .66, w * .05, h * .34), Paint()..color = Colors.white.withOpacity(.18));
        }
        break;
      case 3:
        {
        c.drawRect(Rect.fromLTWH(0, h * .8, w, h), Paint()..color = const Color(0xFF070B22));
        for (double x = 0; x < w; x += 26) {
          final bh = 40 + rnd.nextDouble() * 170;
          c.drawRect(Rect.fromLTWH(x, h * .8 - bh, 24, bh), Paint()..color = const Color(0xFF0B1235));
          for (var k = 0; k < 7; k++) {
            if (rnd.nextBool()) c.drawRect(Rect.fromLTWH(x + 4 + (k % 2) * 10, h * .8 - bh + 10 + (k ~/ 2) * 18, 5, 7), Paint()..color = const Color(0xFFFFD36B));
          }
        }
        final tx = w * .65;
        c.drawPath(Path()..moveTo(tx - 26, h * .8)..lineTo(tx, h * .25)..lineTo(tx + 26, h * .8)..close(), Paint()..color = const Color(0xFF1A2466));
        }
        break;
      default:
        {
        ridge(c, z, h * .55, h * .25, 1, const Color(0xFF3A5D6C));
        ridge(c, z, h * .68, h * .2, 3, const Color(0xFF28444F));
        c.drawRect(Rect.fromLTWH(0, h * .5, w, h * .28), Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.white.withOpacity(0), Colors.white.withOpacity(.35)]).createShader(Rect.fromLTWH(0, h * .5, w, h * .28)));
        ridge(c, z, h * .8, h * .15, 5, const Color(0xFF16313F));
        final px = w * .3;
        for (var i = 0; i < 4; i++) {
          c.drawRect(Rect.fromLTWH(px - 14 + i * 2, h * .8 - 38 * i - 28, 28 - i * 4, 28), Paint()..color = const Color(0xFF0E1E27));
          roof(c, px, h * .8 - 38 * i - 28, 38 - i * 7, 12, const Color(0xFF0E1E27));
        }
        }
    }
  }

  @override
  bool shouldRepaint(ScenePainter o) => o.s != s;
}
