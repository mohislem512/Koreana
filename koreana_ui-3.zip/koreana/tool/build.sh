set -e
flutter create . --org com.koreana --project-name koreana
python3 tool/patch_android.py
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release
