from PIL import Image, ImageDraw
S=2048
def glyph(scale=1.0):
    g=Image.new('RGBA',(S,S),(0,0,0,0)); d=ImageDraw.Draw(g)
    def P(pts): return [(S/2+(x-512)*2*scale, S/2+(y-512)*2*scale) for x,y in pts]
    d.polygon(P([(560,170),(640,200),(300,520),(250,470)]),fill=(230,40,60,255))
    d.polygon(P([(330,250),(450,230),(475,790),(355,810)]),fill=(255,255,255,255))
    d.polygon(P([(455,540),(690,250),(810,285),(570,610)]),fill=(255,255,255,255))
    d.polygon(P([(500,500),(580,490),(800,800),(690,830)]),fill=(255,255,255,255))
    cx,cy=P([(760,720)])[0]; r=105*2*scale
    d.ellipse([cx-r,cy-r,cx+r,cy+r],fill=(224,40,60,255))
    d.pieslice([cx-r,cy-r,cx+r,cy+r],0,180,fill=(35,95,200,255))
    d.ellipse([cx-r/2,cy-r,cx+r/2,cy],fill=(224,40,60,255))
    d.ellipse([cx-r/2,cy,cx+r/2,cy+r],fill=(35,95,200,255))
    return g
def bg():
    b=Image.new('RGBA',(S,S)); px=b.load()
    for y in range(S):
        for x in range(S):
            t=(x+y)/(2*S); px[x,y]=(int(20+60*t),int(24+40*t),int(90+120*t),255)
    return b
full=bg(); full.alpha_composite(glyph(.9))
full.resize((1024,1024),Image.LANCZOS).convert('RGB').save('assets/logo_icon.png')
m=Image.new('L',(S,S),0); ImageDraw.Draw(m).rounded_rectangle([0,0,S,S],radius=460,fill=255)
r=full.copy(); r.putalpha(m); r.resize((512,512),Image.LANCZOS).save('assets/logo.png')
glyph(.62).resize((1024,1024),Image.LANCZOS).save('assets/logo_fg.png')
