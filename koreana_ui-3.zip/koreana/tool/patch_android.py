import re, pathlib
m = pathlib.Path('android/app/src/main/AndroidManifest.xml')
s = m.read_text(encoding='utf8')
perms = '<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    '
intents = ('<intent><action android:name="android.speech.RecognitionService"/></intent>'
           '<intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>'
           '<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>')
if 'android.permission.INTERNET' not in s.replace('debug', ''):
    s = s.replace('<application', perms + '<application', 1)
if '<queries>' in s:
    s = s.replace('<queries>', '<queries>' + intents, 1)
else:
    s = s.replace('<application', '<queries>' + intents + '</queries>\n    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Koreana"', s, count=1)
m.write_text(s, encoding='utf8')
print('manifest patched')
