#!/bin/bash
cd "$(dirname "$0")/.."
flutter create . --org com.koreana --project-name koreana
rm -rf test
python3 tool/patch_android.py
flutter pub get
dart run flutter_launcher_icons
flutter analyze --no-fatal-infos --no-fatal-warnings > analyze.log 2>&1 || true
echo "=========== DART ERRORS ==========="
grep -E " error " analyze.log | head -40
echo "=========== END ==========="
show() { grep -n -E "^e: |e: file|What went wrong|Caused by|Execution failed|Could not|error:" -A3 "$1" | head -60; }
if flutter build apk --release > build.log 2>&1; then exit 0; fi
echo "=========== RELEASE FAILED (try 1) ==========="
show build.log
echo "=========== try 2: newer flutter_tts ==========="
sed -i 's/^  flutter_tts: .*/  flutter_tts: ^4.2.1/' pubspec.yaml
flutter pub get > pubget2.log 2>&1 || tail -15 pubget2.log
grep -E "flutter_tts" pubspec.lock | head -3
if flutter build apk --release > build2.log 2>&1; then exit 0; fi
echo "=========== RELEASE FAILED (try 2) ==========="
show build2.log
echo "=========== TRYING DEBUG ==========="
flutter build apk --debug > build_debug.log 2>&1 || { show build_debug.log; exit 1; }
