import 'package:flutter/material.dart';
import 'auth.dart';
import 'data.dart';
import 'i18n.dart';
import 'lessons.dart';
import 'premium.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

Widget langChips() => StatefulBuilder(
      builder: (c, set) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (final e in [[0, 'العربية'], [1, 'English'], [2, 'Français']])
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: Text('${e[1]}'),
              selected: gLang == e[0],
              onSelected: (_) => AppState.i.setLang(e[0] as int),
            ),
          ),
      ]),
    );

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              langChips(),
              const Spacer(),
              const Logo(130),
              const SizedBox(height: 14),
              const Text('Koreana', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w800, color: Colors.white)),
              const SizedBox(height: 6),
              Text(t('tag'), style: const TextStyle(color: Colors.white70, fontSize: 16)),
              const Spacer(),
              GradientButton(t('start'), () => Navigator.pushNamed(context, '/auth', arguments: true)),
              const SizedBox(height: 10),
              OutlinedButton(
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                onPressed: () => Navigator.pushNamed(context, '/auth', arguments: false),
                child: Text(t('login')),
              ),
            ]),
          ),
        ),
      );
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthState();
}

class _AuthState extends State<AuthScreen> {
  final name = TextEditingController(), email = TextEditingController(), pass = TextEditingController();
  String err = '', info = '';
  bool busy = false;

  Future<void> _go(bool reg) async {
    final n = name.text.trim(), e = email.text.trim(), p = pass.text;
    if (e.isEmpty || p.isEmpty || (reg && n.isEmpty)) return setState(() => err = t('fill'));
    if (reg && p.length < 8) return setState(() => err = t('weak'));
    setState(() { busy = true; err = ''; });
    try {
      if (reg) { await Auth.signUp(n, e, p); } else { await Auth.signIn(e, p); }
      await AppState.i.loadUser();
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, AppState.i.onb ? '/home' : '/levels', (_) => false);
    } on AuthError catch (x) {
      setState(() => err = x.msg);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final reg = (ModalRoute.of(context)?.settings.arguments as bool?) ?? false;
    Widget f(TextEditingController c, String l, {bool pw = false, TextInputType? k}) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: TextField(controller: c, obscureText: pw, keyboardType: k, autocorrect: false, decoration: InputDecoration(labelText: l, filled: true, fillColor: KColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
        );
    return Scaffold(
      appBar: AppBar(title: Text(t(reg ? 'start' : 'login'))),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        const Center(child: Logo(90)),
        const SizedBox(height: 20),
        if (reg) f(name, t('name')),
        f(email, t('email'), k: TextInputType.emailAddress),
        f(pass, t('pass'), pw: true),
        if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(err, style: const TextStyle(color: Colors.redAccent))),
        if (info.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(info, style: const TextStyle(color: KColors.green))),
        GradientButton(busy ? '...' : t(reg ? 'start' : 'login'), busy ? null : () => _go(reg)),
        if (!reg && Auth.cloud)
          TextButton(
            onPressed: () async {
              try { await Auth.reset(email.text.trim()); setState(() => info = t('sent')); } on AuthError catch (x) { setState(() => err = x.msg); }
            },
            child: Text(t('forgot')),
          ),
        if (!Auth.cloud) Padding(padding: const EdgeInsets.only(top: 14), child: Text(t('local'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12))),
      ]),
    );
  }
}

class LevelScreen extends StatelessWidget {
  const LevelScreen({super.key});
  static const cols = [KColors.green, KColors.gold, Color(0xFFB04FD8), KColors.blue, KColors.orange];
  static const icons = [Icons.eco, Icons.emoji_events, Icons.explore, Icons.rocket_launch, Icons.star];
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('chooseLevel'))),
        body: Watch((_) => ListView(padding: const EdgeInsets.all(16), children: [
              for (var i = 0; i < 5; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      if (AppState.i.locked(i)) {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const PaywallScreen()));
                      } else {
                        AppState.i.setLevel(i);
                        Navigator.pushNamedAndRemoveUntil(context, '/home', (_) => false);
                      }
                    },
                    child: KCard(
                      child: Row(children: [
                        CircleAvatar(radius: 26, backgroundColor: cols[i], child: Icon(icons[i], color: Colors.white)),
                        const SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(t('lv$i'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                          Text(t('ld$i'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
                        ])),
                        Icon(AppState.i.locked(i) ? Icons.lock : Icons.chevron_left, color: AppState.i.locked(i) ? KColors.gold : Colors.white38),
                      ]),
                    ),
                  ),
                ),
            ])),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int i = 0;
  @override
  Widget build(BuildContext context) {
    const pages = [HomeTab(), LessonsTab(), CultureTab(), MoreTab()];
    return Scaffold(
      body: SafeArea(child: pages[i]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v) => setState(() => i = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: t('home')),
          NavigationDestination(icon: const Icon(Icons.menu_book_outlined), selectedIcon: const Icon(Icons.menu_book), label: t('lessons')),
          NavigationDestination(icon: const Icon(Icons.public), label: t('culture')),
          NavigationDestination(icon: const Icon(Icons.menu), label: t('more')),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  Widget stat(IconData ic, Color c, String v, String l) => Expanded(
        child: KCard(padding: const EdgeInsets.all(10), child: Column(children: [
          Icon(ic, color: c),
          Text(v, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          Text(l, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: Colors.white60)),
        ])),
      );
  void go(BuildContext c, String route) {
    if (AppState.i.locked(AppState.i.level)) {
      Navigator.push(c, MaterialPageRoute(builder: (_) => const PaywallScreen()));
    } else {
      Navigator.pushNamed(c, route);
    }
  }

  @override
  Widget build(BuildContext context) => Watch((c) {
        final s = AppState.i;
        final name = Auth.user?.name ?? '';
        final skills = [
          [Icons.menu_book, KColors.primary, 'reading', '/reading'],
          [Icons.headphones, KColors.blue, 'listening', '/listening'],
          [Icons.record_voice_over, KColors.orange, 'pron', '/pronounce'],
          [Icons.chat_bubble, Colors.pinkAccent, 'chat', '/chat'],
          [Icons.style, KColors.green, 'vocab', '/vocab'],
        ];
        return ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            CircleAvatar(backgroundColor: KColors.primary, child: Text(name.isEmpty ? '?' : name[0].toUpperCase(), style: const TextStyle(color: Colors.white))),
            const SizedBox(width: 10),
            Expanded(child: Text('${t('hello')} $name', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
            if (s.premium) Chip(avatar: const Icon(Icons.verified, color: KColors.gold, size: 18), label: Text(t('verified'), style: const TextStyle(fontSize: 11))),
          ]),
          const SizedBox(height: 14),
          KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('yourLevel'), style: const TextStyle(color: Colors.white60)),
            Text(t('lv${s.level}'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text('📍 ${places[s.level][gLang]}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            KProgress(s.lxp / 100),
          ])),
          const SizedBox(height: 10),
          Row(children: [
            stat(Icons.check_circle, KColors.gold, '${s.done}', t('done')),
            const SizedBox(width: 8),
            stat(Icons.local_fire_department, KColors.orange, '${s.streak}', t('streak')),
            const SizedBox(width: 8),
            stat(Icons.star, KColors.gold, '${s.xp}', t('points')),
          ]),
          const SizedBox(height: 12),
          GradientButton(t('continue'), () => go(context, '/vocab')),
          const SizedBox(height: 18),
          Text(t('skills'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 1.15,
            children: [
              for (final k in skills)
                InkWell(
                  onTap: () => go(context, k[3] as String),
                  child: Container(
                    decoration: BoxDecoration(color: k[1] as Color, borderRadius: BorderRadius.circular(18)),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(k[0] as IconData, color: Colors.white, size: 28),
                      const SizedBox(height: 4),
                      Text(t(k[2] as String), style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
            ],
          ),
        ]);
      });
}

class LessonsTab extends StatelessWidget {
  const LessonsTab({super.key});
  @override
  Widget build(BuildContext context) => Watch((_) {
        final lv = AppState.i.level;
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text(t('lv$lv'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          for (final l in [...lessons[lv], ...moreLessons[lv]])
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: KCard(
                padding: EdgeInsets.zero,
                child: ExpansionTile(
                  title: Text(l.title[gLang], style: const TextStyle(fontWeight: FontWeight.w700)),
                  childrenPadding: const EdgeInsets.all(14),
                  children: [
                    Text(l.body[gLang], style: const TextStyle(height: 1.6)),
                    const SizedBox(height: 8),
                    for (final w in l.ex)
                      ListTile(
                        dense: true,
                        leading: const Icon(Icons.volume_up, color: KColors.primary),
                        title: Text(w.ko, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                        subtitle: Text('${w.rom}  ${w.rom.isEmpty ? '' : '·'}  ${w.tr}'),
                        onTap: () => AppState.i.speak(w.ko),
                      ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 6),
          Text('${t('phrases')} (${reading[lv].length})', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          for (final w in reading[lv])
            ListTile(
              dense: true,
              leading: const Icon(Icons.volume_up, color: KColors.primary),
              title: Text(w.ko, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              subtitle: Text('${w.rom}\n${w.tr}'),
              isThreeLine: true,
              onTap: () => AppState.i.speak(w.ko),
            ),
          const SizedBox(height: 6),
          Text('${t('vocab')} (${vocab[lv].length})', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          for (final w in vocab[lv])
            ListTile(
              leading: const Icon(Icons.volume_up, color: KColors.primary),
              title: Text(w.ko, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              subtitle: Text(w.rom),
              trailing: Text(w.tr),
              onTap: () => AppState.i.speak(w.ko),
            ),
        ]);
      });
}

class CultureTab extends StatelessWidget {
  const CultureTab({super.key});
  @override
  Widget build(BuildContext context) => Watch((_) => ListView(padding: const EdgeInsets.all(16), children: [
        Text(t('culture'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        KCard(child: Row(children: [
          const Icon(Icons.place, color: KColors.gold, size: 32),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('place'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
            Text(places[AppState.i.level][gLang], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ])),
        ])),
        const SizedBox(height: 10),
        for (final k in ['hangul', 'kimchi', 'respect'])
          Padding(padding: const EdgeInsets.only(bottom: 10), child: KCard(child: Text(t(k), style: const TextStyle(height: 1.6)))),
      ]));
}

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});
  @override
  Widget build(BuildContext context) => Watch((_) {
        final u = Auth.user;
        return ListView(padding: const EdgeInsets.all(16), children: [
          KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(u?.name ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            Text(u?.email ?? '', style: const TextStyle(color: Colors.white60)),
            if (AppState.i.premium) Text('${t('until')} ${AppState.i.until!.toLocal().toString().substring(0, 10)}', style: const TextStyle(color: KColors.gold)),
          ])),
          const SizedBox(height: 10),
          ListTile(leading: const Icon(Icons.workspace_premium, color: KColors.gold), title: Text(t('premium')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PaywallScreen()))),
          ListTile(leading: const Icon(Icons.swap_vert), title: Text(t('changeLevel')), onTap: () => Navigator.pushNamed(context, '/levels')),
          ListTile(leading: const Icon(Icons.rate_review_outlined), title: Text(t('feedback')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FeedbackScreen(level: AppState.i.level)))),
          Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: langChips()),
          ListTile(
            leading: const Icon(Icons.logout),
            title: Text(t('logout')),
            onTap: () async {
              await Auth.signOut();
              AppState.i.reset();
              if (context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
            title: Text(t('delete'), style: const TextStyle(color: Colors.redAccent)),
            onTap: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (d) => AlertDialog(
                  content: Text(t('sure')),
                  actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(t('cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(t('confirm')))],
                ),
              );
              if (ok == true) {
                try { await Auth.deleteAccount(); } catch (_) {}
                AppState.i.reset();
                if (context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
              }
            },
          ),
        ]);
      });
}
