import 'dart:math';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'data.dart';
import 'i18n.dart';
import 'srs.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

List<W> poolMixed() => [...vocab[AppState.i.level], ...reading[AppState.i.level]];

// ---------------- Listening ----------------
class ListeningScreen extends StatefulWidget {
  const ListeningScreen({super.key});
  @override
  State<ListeningScreen> createState() => _LiS();
}

class _LiS extends State<ListeningScreen> {
  late W cur;
  late List<W> opts;
  W? pick;
  int ok = 0, n = 0;
  @override
  void initState() {
    super.initState();
    _new();
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.i.speak(cur.ko));
  }

  void _new() {
    final all = poolMixed();
    cur = Srs.next(all);
    final long = cur.ko.length > 8;
    final same = all.where((w) => (w.ko.length > 8) == long && w != cur).toList()..shuffle();
    opts = [cur, ...same.take(3)]..shuffle();
    pick = null;
  }

  void _tap(W w) {
    if (pick != null) return;
    setState(() { pick = w; n++; if (w == cur) ok++; });
    Srs.grade(cur, w == cur);
    if (w == cur) AppState.i.addXp(5, lesson: true);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('listening'))),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Text(t('listenQ'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 20),
          Center(
            child: InkWell(
              onTap: () => AppState.i.speak(cur.ko),
              child: Container(width: 100, height: 100, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: KColors.grad), child: const Icon(Icons.volume_up, size: 48, color: Colors.white)),
            ),
          ),
          const SizedBox(height: 8),
          Center(child: Text('$ok / $n', style: const TextStyle(color: Colors.white60))),
          const SizedBox(height: 16),
          for (final w in opts) Opt(w.tr, pick == null ? 0 : (w == cur ? 1 : (w == pick ? 2 : 0)), () => _tap(w)),
          if (pick != null) ...[
            Center(child: Text(pick == cur ? t('good') : t('bad'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
            const SizedBox(height: 6),
            Center(child: Text('${cur.ko}\n${cur.rom}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))),
            const SizedBox(height: 12),
            GradientButton(t('next'), () { setState(_new); AppState.i.speak(cur.ko); }),
          ],
        ]),
      );
}

// ---------------- Pronunciation ----------------
int lev(String a, String b) {
  final m = List.generate(a.length + 1, (i) => List<int>.filled(b.length + 1, 0));
  for (var i = 0; i <= a.length; i++) { m[i][0] = i; }
  for (var j = 0; j <= b.length; j++) { m[0][j] = j; }
  for (var i = 1; i <= a.length; i++) {
    for (var j = 1; j <= b.length; j++) {
      m[i][j] = min(min(m[i - 1][j] + 1, m[i][j - 1] + 1), m[i - 1][j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
    }
  }
  return m[a.length][b.length];
}

class PronounceScreen extends StatefulWidget {
  const PronounceScreen({super.key});
  @override
  State<PronounceScreen> createState() => _PrS();
}

class _PrS extends State<PronounceScreen> {
  final stt = SpeechToText();
  bool ready = false, listening = false;
  late W w;
  String heard = '', msg = '';
  int? score;

  @override
  void initState() {
    super.initState();
    w = Srs.next(poolMixed());
  }

  Future<void> _listen() async {
    if (!ready) {
      ready = await stt.initialize(
        onStatus: (s) {
          if ((s == 'done' || s == 'notListening') && mounted) {
            setState(() => listening = false);
            if (score == null && heard.isNotEmpty) _score();
          }
        },
        onError: (_) { if (mounted) setState(() => listening = false); },
      );
    }
    if (!ready) return setState(() => msg = t('micErr'));
    setState(() { listening = true; heard = ''; score = null; msg = ''; });
    await stt.listen(localeId: 'ko_KR', onResult: (r) {
      setState(() => heard = r.recognizedWords);
      if (r.finalResult) _score();
    });
  }

  void _score() {
    if (score != null || !mounted) return;
    String norm(String s) => s.replaceAll(RegExp(r'[\s?.!,]'), '');
    final a = norm(heard), b = norm(w.ko);
    final sim = 1 - lev(a, b) / max(1, max(a.length, b.length));
    setState(() => score = (sim * 100).round());
    Srs.grade(w, score! >= 70);
    if (score! >= 70) AppState.i.addXp(10, lesson: true);
  }

  @override
  void dispose() {
    stt.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('pron'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          KCard(
            padding: const EdgeInsets.all(26),
            child: Column(children: [
              Text(w.ko, textAlign: TextAlign.center, style: TextStyle(fontSize: w.ko.length > 8 ? 26 : 46, fontWeight: FontWeight.w800)),
              Text('(${w.rom})', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
              Text(w.tr, textAlign: TextAlign.center, style: const TextStyle(color: KColors.primary, fontWeight: FontWeight.w700)),
              const SizedBox(height: 18),
              OutlinedButton.icon(onPressed: () => AppState.i.speak(w.ko), icon: const Icon(Icons.play_arrow), label: Text(t('play'))),
              const SizedBox(height: 18),
              InkWell(
                onTap: listening ? null : _listen,
                child: Container(
                  width: 88, height: 88,
                  decoration: BoxDecoration(shape: BoxShape.circle, gradient: KColors.grad, boxShadow: listening ? [BoxShadow(color: KColors.primary.withOpacity(.7), blurRadius: 24, spreadRadius: 6)] : null),
                  child: Icon(listening ? Icons.hearing : Icons.mic, color: Colors.white, size: 42),
                ),
              ),
              const SizedBox(height: 8),
              Text(t('tapSpeak'), style: const TextStyle(color: KColors.blue)),
              if (heard.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text('${t('heard')} $heard', style: const TextStyle(fontSize: 16))),
              if (score != null) Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('${t('accuracy')}: $score%  ${score! >= 70 ? '✅' : '🔁'}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: score! >= 70 ? KColors.green : KColors.orange)),
              ),
              if (msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
            ]),
          ),
          const SizedBox(height: 14),
          GradientButton(t('next'), () => setState(() { w = Srs.next(poolMixed()); heard = ''; score = null; msg = ''; })),
        ]),
      );
}

// ---------------- Reading ----------------
class ReadingScreen extends StatefulWidget {
  const ReadingScreen({super.key});
  @override
  State<ReadingScreen> createState() => _ReS();
}

class _ReS extends State<ReadingScreen> {
  bool show = false;
  String? pick;
  late W cur;
  late List<String> opts;
  final r = Random();
  @override
  void initState() {
    super.initState();
    _new();
  }

  void _new() {
    cur = Srs.next(reading[AppState.i.level]);
    final all = [for (final l in reading) ...l];
    final s = <String>{cur.tr};
    var guard = 0;
    while (s.length < 3 && guard++ < 60) { s.add(all[r.nextInt(all.length)].tr); }
    opts = s.toList()..shuffle();
    pick = null;
    show = false;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('reading'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          KCard(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              Text(cur.ko, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, height: 1.5)),
              Text(cur.rom, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
              const SizedBox(height: 6),
              IconButton(iconSize: 36, color: KColors.primary, onPressed: () => AppState.i.speak(cur.ko), icon: const Icon(Icons.volume_up)),
              TextButton(onPressed: () => setState(() => show = !show), child: Text(t('showTr'))),
              if (show) Text(cur.tr, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 16),
          Text(t('meaning'), style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (final o in opts)
            Opt(o, pick == null ? 0 : (o == cur.tr ? 1 : (o == pick ? 2 : 0)), () {
              if (pick != null) return;
              setState(() => pick = o);
              Srs.grade(cur, o == cur.tr);
              if (o == cur.tr) AppState.i.addXp(8, lesson: true);
            }),
          if (pick != null) GradientButton(t('next'), () => setState(_new)),
        ]),
      );
}

// ---------------- Vocabulary flashcards (spaced repetition) ----------------
class VocabScreen extends StatefulWidget {
  const VocabScreen({super.key});
  @override
  State<VocabScreen> createState() => _VoS();
}

class _VoS extends State<VocabScreen> {
  late W w;
  bool flip = false;
  List<W> get pool => vocab[AppState.i.level];
  @override
  void initState() {
    super.initState();
    w = Srs.next(pool);
  }

  void _next() => setState(() { w = Srs.next(pool); flip = false; });

  @override
  Widget build(BuildContext context) {
    final nk = Srs.learned(pool);
    return Scaffold(
      appBar: AppBar(title: Text(t('vocab'))),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          KProgress(nk / pool.length),
          const SizedBox(height: 6),
          Text('$nk / ${pool.length} ${t('learned')}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
          const SizedBox(height: 14),
          Expanded(
            child: InkWell(
              onTap: () { setState(() => flip = !flip); AppState.i.speak(w.ko); },
              child: KCard(
                padding: const EdgeInsets.all(28),
                child: SizedBox(
                  width: double.infinity,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(w.ko, textAlign: TextAlign.center, style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800)),
                    Text('(${w.rom})', style: const TextStyle(color: Colors.white60)),
                    const SizedBox(height: 18),
                    Text(flip ? w.tr : t('flip'), textAlign: TextAlign.center, style: TextStyle(fontSize: flip ? 24 : 13, color: flip ? KColors.primary : Colors.white38, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 14),
                    const Icon(Icons.volume_up, color: KColors.primary),
                  ]),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () { Srs.grade(w, false); _next(); }, child: Text(t('again')))),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton(
                onPressed: () {
                  if (Srs.box(w) < 3) AppState.i.addXp(3, lesson: true);
                  Srs.grade(w, true);
                  _next();
                },
                child: Text(t('known')),
              ),
            ),
          ]),
        ]),
      ),
    );
  }
}

// ---------------- Chat (guided Korean conversation) ----------------
class Msg {
  final W w;
  final bool bot;
  Msg(this.w, this.bot);
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChS();
}

class _ChS extends State<ChatScreen> {
  late List<Turn> script;
  int turn = 0;
  final msgs = <Msg>[];
  final ctl = TextEditingController(), sc = ScrollController();

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    script = chatScripts[AppState.i.level < 2 ? 0 : 1];
    turn = 0;
    msgs..clear()..add(Msg(script[0].bot, true));
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.i.speak(script[0].bot.ko));
  }

  void _scroll() => Future.delayed(const Duration(milliseconds: 150), () {
        if (sc.hasClients) sc.animateTo(sc.position.maxScrollExtent + 200, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  void _send(W me) {
    if (turn >= script.length) return;
    setState(() => msgs.add(Msg(me, false)));
    _scroll();
    Future.delayed(const Duration(milliseconds: 700), () {
      if (!mounted) return;
      setState(() {
        turn++;
        if (turn < script.length) {
          msgs.add(Msg(script[turn].bot, true));
          AppState.i.speak(script[turn].bot.ko);
        } else {
          msgs.add(Msg(W('정말 잘했어요!', 'jeongmal jalhaesseoyo', 'أحسنت!', 'Well done!', 'Bravo !'), true));
          AppState.i.addXp(15, lesson: true);
        }
      });
      _scroll();
    });
  }

  Widget bubble(Msg m) => Align(
        alignment: m.bot ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(12),
          constraints: const BoxConstraints(maxWidth: 300),
          decoration: BoxDecoration(color: m.bot ? const Color(0xFFF1F2FA) : const Color(0xFFDCE8FB), borderRadius: BorderRadius.circular(18)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisSize: MainAxisSize.min, children: [
              Flexible(child: Text(m.w.ko, style: const TextStyle(color: Colors.black87, fontSize: 16, fontWeight: FontWeight.w700))),
              InkWell(onTap: () => AppState.i.speak(m.w.ko), child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.volume_up, size: 18, color: KColors.primary))),
            ]),
            if (m.w.rom.isNotEmpty) Text(m.w.rom, style: const TextStyle(color: Colors.black45, fontSize: 11)),
            if (m.w.tr.isNotEmpty) Text(m.w.tr, style: const TextStyle(color: Colors.black87, fontSize: 13)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final done = turn >= script.length;
    return Scaffold(
      appBar: AppBar(title: Text(t('chat'))),
      body: Column(children: [
        Expanded(child: ListView(controller: sc, padding: const EdgeInsets.all(16), children: [for (final m in msgs) bubble(m)])),
        if (!done)
          SizedBox(
            height: 64,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
              for (final r in script[turn].replies)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ActionChip(label: Text('${r.ko}\n${r.tr}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)), onPressed: () => _send(r)),
                ),
            ]),
          )
        else
          Padding(padding: const EdgeInsets.all(12), child: GradientButton(t('restart'), () => setState(_start))),
        if (!done)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            child: Row(children: [
              Expanded(child: TextField(controller: ctl, decoration: InputDecoration(hintText: t('typeMsg'), filled: true, fillColor: KColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(24))))),
              IconButton(
                onPressed: () {
                  final s = ctl.text.trim();
                  if (s.isEmpty) return;
                  ctl.clear();
                  _send(W(s, '', '', '', ''));
                },
                icon: const Icon(Icons.send, color: KColors.primary),
              ),
            ]),
          ),
      ]),
    );
  }
}
