import 'dart:math';
import 'data.dart';
import 'state.dart';

/// Spaced repetition (Leitner boxes): no immediate repeats, new items are
/// mixed with items that are due for review; wrong answers come back sooner.
class Srs {
  static final _r = Random();
  static final List<String> _recent = [];
  static const _minutes = [0, 10, 1440, 4320, 10080, 20160];

  static int box(W w) => AppState.i.srs[w.ko]?[0] ?? -1;
  static int learned(List<W> pool) => pool.where((w) => box(w) >= 3).length;

  static W next(List<W> pool) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final s = AppState.i.srs;
    List<W> cand(bool Function(W) f) => pool.where((w) => f(w) && !_recent.contains(w.ko)).toList();
    final fresh = cand((w) => !s.containsKey(w.ko));
    final due = cand((w) => s.containsKey(w.ko) && s[w.ko]![1] <= now);
    List<W> pick;
    if (due.isNotEmpty && (fresh.isEmpty || _r.nextDouble() < .4)) {
      pick = due;
    } else if (fresh.isNotEmpty) {
      pick = fresh;
    } else {
      final rest = pool.where((w) => !_recent.contains(w.ko)).toList()
        ..sort((a, b) => (s[a.ko]?[1] ?? 0).compareTo(s[b.ko]?[1] ?? 0));
      pick = rest.isEmpty ? pool : rest.take(5).toList();
    }
    final w = pick[_r.nextInt(pick.length)];
    _recent.add(w.ko);
    final keep = min(12, max(1, pool.length ~/ 2));
    while (_recent.length > keep) { _recent.removeAt(0); }
    return w;
  }

  static void grade(W w, bool ok) {
    final cur = box(w);
    final b = ok ? min(5, (cur < 0 ? 0 : cur) + 1) : 0;
    AppState.i.srs[w.ko] = [b, DateTime.now().millisecondsSinceEpoch + _minutes[b] * 60000];
    AppState.i.saveSrs();
  }
}
