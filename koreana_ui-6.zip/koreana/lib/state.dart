import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth.dart';
import 'i18n.dart';
import 'premium.dart';

class AppState extends ChangeNotifier {
  static final AppState i = AppState._();
  AppState._();
  late SharedPreferences p;
  String uid = '';
  int level = 0, xp = 0, lxp = 0, streak = 0, done = 0, lang = 0;
  bool onb = false;
  String last = '';
  Set<String> known = {};
  Map<String, List<int>> srs = {};
  DateTime? until;
  final tts = FlutterTts();
  final nav = GlobalKey<NavigatorState>();
  final msgKey = GlobalKey<ScaffoldMessengerState>();
  final langV = ValueNotifier<int>(0);

  bool get premium => until != null && until!.isAfter(DateTime.now());
  bool locked(int lv) => lv >= 2 && !premium;
  String k(String s) => '${uid}_$s';

  Future<void> boot() async {
    p = await SharedPreferences.getInstance();
    lang = p.getInt('lang') ?? 0;
    gLang = lang;
    langV.value = lang;
    await Auth.restore();
    if (Auth.user != null) await loadUser();
    try {
      await tts.setLanguage('ko-KR');
      await tts.setSpeechRate(.4);
    } catch (_) {}
  }

  Future<void> loadUser() async {
    uid = Auth.user!.uid;
    level = p.getInt(k('level')) ?? 0;
    xp = p.getInt(k('xp')) ?? 0;
    lxp = p.getInt(k('lxp')) ?? 0;
    streak = p.getInt(k('streak')) ?? 0;
    done = p.getInt(k('done')) ?? 0;
    onb = p.getBool(k('onb')) ?? false;
    last = p.getString(k('last')) ?? '';
    known = (p.getStringList(k('known')) ?? []).toSet();
    srs = {};
    for (final e in (p.getStringList(k('srs')) ?? [])) {
      final q = e.split('|');
      if (q.length == 3) srs[q[0]] = [int.tryParse(q[1]) ?? 0, int.tryParse(q[2]) ?? 0];
    }
    final ts = p.getInt(k('ts')) ?? 0;
    final r = await Auth.pull();
    if (r != null && (r['ts'] ?? 0) is int && (r['ts'] as int) > ts) {
      level = r['level'] ?? level;
      xp = r['xp'] ?? xp;
      lxp = r['lxp'] ?? lxp;
      streak = r['streak'] ?? streak;
      done = r['done'] ?? done;
      onb = (r['onb'] ?? (onb ? 1 : 0)) == 1;
      last = r['last'] ?? last;
      known = Set<String>.from((r['known'] ?? []) as List);
    }
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (last != today) {
      final y = DateTime.now().subtract(const Duration(days: 1)).toIso8601String().substring(0, 10);
      streak = last == y ? streak + 1 : 1;
      last = today;
    }
    await save();
    notifyListeners();
    refreshPremium();
  }

  void reset() {
    uid = '';
    level = xp = lxp = streak = done = 0;
    onb = false;
    known = {};
    srs = {};
    until = null;
    notifyListeners();
  }

  Future<void> save() async {
    if (uid.isEmpty) return;
    final ts = DateTime.now().millisecondsSinceEpoch;
    await p.setInt(k('level'), level);
    await p.setInt(k('xp'), xp);
    await p.setInt(k('lxp'), lxp);
    await p.setInt(k('streak'), streak);
    await p.setInt(k('done'), done);
    await p.setBool(k('onb'), onb);
    await p.setString(k('last'), last);
    await p.setStringList(k('known'), known.toList());
    await p.setInt(k('ts'), ts);
    Auth.push({'level': level, 'xp': xp, 'lxp': lxp, 'streak': streak, 'done': done, 'onb': onb ? 1 : 0, 'last': last, 'known': known.toList(), 'ts': ts});
  }

  Future<void> saveSrs() async {
    if (uid.isEmpty) return;
    await p.setStringList(k('srs'), [for (final e in srs.entries) '${e.key}|${e.value[0]}|${e.value[1]}']);
  }

  Future<void> refreshPremium() async {
    until = await Auth.entitlement();
    if (lxp >= 100 && level < 4 && !locked(level + 1)) {
      level++;
      lxp = 0;
      _snack(t('levelUp'));
      await save();
    }
    notifyListeners();
  }

  void setLevel(int l) {
    level = l;
    lxp = 0;
    onb = true;
    save();
    notifyListeners();
  }

  void setLang(int l) {
    lang = l;
    gLang = l;
    p.setInt('lang', l);
    langV.value = l;
  }

  void _snack(String s) => msgKey.currentState?.showSnackBar(SnackBar(content: Text(s)));

  void addXp(int n, {bool lesson = false}) {
    xp += n;
    if (lesson) done++;
    final before = lxp;
    lxp += n;
    if (lxp >= 100 && before < 100 && level < 4) {
      final old = level;
      final lock = locked(level + 1);
      if (lock) {
        lxp = 100;
      } else {
        level++;
        lxp = 0;
        _snack(t('levelUp'));
      }
      if (!(p.getBool(k('fb$old')) ?? false)) {
        p.setBool(k('fb$old'), true);
        nav.currentState?.push(MaterialPageRoute(builder: (_) => FeedbackScreen(level: old, thenPaywall: lock)));
      } else if (lock) {
        nav.currentState?.push(MaterialPageRoute(builder: (_) => const PaywallScreen()));
      }
    }
    save();
    notifyListeners();
  }

  Future<void> speak(String s) async {
    try {
      await tts.stop();
      await tts.setLanguage('ko-KR');
      await tts.speak(s);
    } catch (_) {}
  }
}
