// Cloudflare Worker: receives Lemon Squeezy webhooks and grants premium in Firestore.
// Secrets/vars (Cloudflare dashboard): LS_SECRET, SA_JSON (secrets) | PROJECT_ID, PLANS, ALLOW_TEST (text)
// PLANS example: {"111111":1,"222222":2,"333333":3}  (Lemon Squeezy variant id -> months)
export default {
  async fetch(req, env) {
    if (req.method !== 'POST') return new Response('ok');
    const raw = await req.text();
    if (!(await verify(raw, req.headers.get('X-Signature') || '', env.LS_SECRET))) return new Response('bad signature', { status: 401 });
    const ev = JSON.parse(raw);
    const name = ev.meta && ev.meta.event_name;
    const uid = ev.meta && ev.meta.custom_data && ev.meta.custom_data.uid;
    const a = (ev.data && ev.data.attributes) || {};
    if (!uid || !/^[A-Za-z0-9]{6,64}$/.test(uid)) return new Response('no uid');
    if (a.test_mode && env.ALLOW_TEST !== 'true') return new Response('test ignored');
    const variant = String(a.first_order_item && a.first_order_item.variant_id);
    const months = JSON.parse(env.PLANS)[variant];
    if (!months) return new Response('unknown variant');
    if (name === 'order_created' && a.status === 'paid') await grant(env, uid, months, 'o' + ev.data.id);
    if (name === 'order_refunded') await grant(env, uid, -months, 'r' + ev.data.id);
    return new Response('ok');
  },
};

async function verify(raw, sig, secret) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(raw));
  const hex = [...new Uint8Array(mac)].map((b) => b.toString(16).padStart(2, '0')).join('');
  if (hex.length !== sig.length) return false;
  let d = 0;
  for (let i = 0; i < hex.length; i++) d |= hex.charCodeAt(i) ^ sig.charCodeAt(i);
  return d === 0;
}

const b64u = (s) => btoa(s).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

async function token(env) {
  const sa = JSON.parse(env.SA_JSON);
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64u(JSON.stringify({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/datastore', aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 }));
  const pem = sa.private_key.replace(/-----[^-]+-----/g, '').replace(/\s/g, '');
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(head + '.' + claim));
  const s = b64u(String.fromCharCode(...new Uint8Array(sig)));
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=' + head + '.' + claim + '.' + s,
  });
  return (await r.json()).access_token;
}

async function grant(env, uid, months, oid) {
  const tk = await token(env);
  const url = `https://firestore.googleapis.com/v1/projects/${env.PROJECT_ID}/databases/(default)/documents/entitlements/${uid}`;
  const r = await fetch(url, { headers: { Authorization: 'Bearer ' + tk } });
  let until = 0, processed = [];
  if (r.ok) {
    const f = (await r.json()).fields || {};
    if (f.until) until = Date.parse(f.until.timestampValue);
    processed = (((f.processed || {}).arrayValue || {}).values || []).map((v) => v.stringValue);
  }
  if (processed.includes(oid)) return; // idempotent
  const now = Date.now();
  let next = (months > 0 ? Math.max(now, until) : until) + months * 30 * 86400000;
  if (months < 0 && next < now) next = now;
  processed.push(oid);
  await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: 'Bearer ' + tk, 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields: { until: { timestampValue: new Date(next).toISOString() }, verified: { booleanValue: true }, processed: { arrayValue: { values: processed.map((s) => ({ stringValue: s })) } } } }),
  });
}
