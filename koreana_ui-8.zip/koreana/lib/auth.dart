import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'i18n.dart';

class AuthError implements Exception {
  final String msg;
  AuthError(this.msg);
}

class User {
  String uid, email, name;
  String? idToken, refresh;
  DateTime exp = DateTime(2000);
  bool verified = false;
  User(this.uid, this.email, this.name);
}

class Auth {
  static const _ss = FlutterSecureStorage();
  static User? user;
  static bool get cloud => kApiKey.isNotEmpty && !kApiKey.startsWith('PASTE');
  static String? checkoutBase(int plan) => {1: kLsUrl1, 2: kLsUrl2, 3: kLsUrl3}[plan];
  static bool get payReady => cloud && [kLsUrl1, kLsUrl2, kLsUrl3].every((u) => u.startsWith('http'));
  static const _idt = 'https://identitytoolkit.googleapis.com/v1/accounts';
  static String get _fs => 'https://firestore.googleapis.com/v1/projects/$kProjectId/databases/(default)/documents';

  static String _msg(String m) {
    if (m.contains('EMAIL_EXISTS')) return t('e_exists');
    if (m.contains('WEAK_PASSWORD')) return t('e_weak');
    if (m.contains('INVALID_EMAIL')) return t('e_mail');
    if (m.contains('TOO_MANY')) return t('e_many');
    if (m.contains('INVALID_LOGIN') || m.contains('INVALID_PASSWORD') || m.contains('EMAIL_NOT_FOUND')) return t('e_cred');
    return t('e_gen');
  }

  static Future<Map> _call(String method, String url, {Map? body, String? token, bool soft404 = false}) async {
    try {
      final h = {'Content-Type': 'application/json', if (token != null) 'Authorization': 'Bearer $token'};
      final u = Uri.parse(url);
      final http.Response r = method == 'GET'
          ? await http.get(u, headers: h)
          : method == 'DELETE'
              ? await http.delete(u, headers: h)
              : method == 'PATCH'
                  ? await http.patch(u, headers: h, body: jsonEncode(body))
                  : await http.post(u, headers: h, body: jsonEncode(body));
      if (r.statusCode == 404 && soft404) return {};
      final dynamic j = r.body.isEmpty ? {} : jsonDecode(r.body);
      if (r.statusCode >= 400) {
        final e = j is Map ? j['error'] : null;
        throw AuthError(_msg(e is Map ? '${e['message']}' : ''));
      }
      return j is Map ? j : {};
    } on AuthError {
      rethrow;
    } catch (_) {
      throw AuthError(t('e_net'));
    }
  }

  static Future<void> _save() async {
    final u = user;
    if (u == null) return;
    await _ss.write(key: 'session', value: jsonEncode({'uid': u.uid, 'email': u.email, 'name': u.name, 'refresh': u.refresh}));
  }

  static void _tokens(User u, Map j) {
    u.idToken = (j['idToken'] ?? j['id_token']) as String?;
    u.refresh = (j['refreshToken'] ?? j['refresh_token']) as String?;
    final s = int.tryParse('${j['expiresIn'] ?? j['expires_in'] ?? 3600}') ?? 3600;
    u.exp = DateTime.now().add(Duration(seconds: s));
  }

  static Future<void> restore() async {
    try {
      final raw = await _ss.read(key: 'session');
      if (raw == null) return;
      final m = jsonDecode(raw) as Map;
      final u = User('${m['uid']}', '${m['email']}', '${m['name']}')..refresh = m['refresh'] as String?;
      user = u;
      if (cloud) await fresh();
    } catch (_) {}
  }

  static Future<String?> fresh() async {
    final u = user;
    if (u == null || !cloud) return null;
    if (u.idToken != null && DateTime.now().isBefore(u.exp.subtract(const Duration(seconds: 90)))) return u.idToken;
    if (u.refresh == null) return u.idToken;
    try {
      final r = await http.post(Uri.parse('https://securetoken.googleapis.com/v1/token?key=$kApiKey'), body: {'grant_type': 'refresh_token', 'refresh_token': u.refresh!});
      if (r.statusCode == 200) {
        _tokens(u, jsonDecode(r.body) as Map);
        await _save();
      } else if (r.statusCode == 400) {
        await signOut(); // revoked / deleted account
        return null;
      }
    } catch (_) {}
    return u.idToken;
  }

  // ---- local-mode password hashing (salted, 20k iterations) ----
  static String _hash(String pass, String salt) {
    var d = Uint8List.fromList(utf8.encode('$salt:$pass'));
    for (var i = 0; i < 20000; i++) {
      d = Uint8List.fromList(sha256.convert(d).bytes);
    }
    return base64Encode(d);
  }

  static String _luid(String e) => sha256.convert(utf8.encode(e.toLowerCase())).toString().substring(0, 20);

  static Future<void> signUp(String name, String email, String pass) async {
    if (cloud) {
      final j = await _call('POST', '$_idt:signUp?key=$kApiKey', body: {'email': email, 'password': pass, 'returnSecureToken': true});
      final u = User('${j['localId']}', email, name);
      _tokens(u, j);
      user = u;
      await _call('POST', '$_idt:update?key=$kApiKey', body: {'idToken': u.idToken, 'displayName': name, 'returnSecureToken': false});
      await sendVerify();
    } else {
      final k = 'acc_${email.toLowerCase()}';
      if (await _ss.read(key: k) != null) throw AuthError(t('e_exists'));
      final salt = DateTime.now().microsecondsSinceEpoch.toString();
      await _ss.write(key: k, value: jsonEncode({'name': name, 'salt': salt, 'hash': _hash(pass, salt)}));
      user = User(_luid(email), email, name);
    }
    await _save();
  }

  static Future<void> signIn(String email, String pass) async {
    if (cloud) {
      final j = await _call('POST', '$_idt:signInWithPassword?key=$kApiKey', body: {'email': email, 'password': pass, 'returnSecureToken': true});
      final u = User('${j['localId']}', email, '${j['displayName'] ?? email.split('@').first}');
      _tokens(u, j);
      user = u;
    } else {
      final raw = await _ss.read(key: 'acc_${email.toLowerCase()}');
      if (raw == null) throw AuthError(t('e_cred'));
      final m = jsonDecode(raw) as Map;
      if (_hash(pass, '${m['salt']}') != m['hash']) throw AuthError(t('e_cred'));
      user = User(_luid(email), email, '${m['name']}');
    }
    await _save();
  }

  static Future<void> signOut() async {
    user = null;
    await _ss.delete(key: 'session');
  }

  static Future<void> reset(String email) => _call('POST', '$_idt:sendOobCode?key=$kApiKey', body: {'requestType': 'PASSWORD_RESET', 'email': email});

  static Future<void> sendVerify() async {
    final tk = await fresh();
    if (tk != null) await _call('POST', '$_idt:sendOobCode?key=$kApiKey', body: {'requestType': 'VERIFY_EMAIL', 'idToken': tk});
  }

  static Future<bool> refreshVerified() async {
    final tk = await fresh();
    if (tk == null) return false;
    final j = await _call('POST', '$_idt:lookup?key=$kApiKey', body: {'idToken': tk});
    final us = j['users'];
    final v = us is List && us.isNotEmpty && us[0]['emailVerified'] == true;
    user!.verified = v;
    return v;
  }

  // ---- Firestore (REST, protected by security rules) ----
  static Map _enc(Map<String, dynamic> d) => {
        'fields': {
          for (final e in d.entries)
            e.key: e.value is int
                ? {'integerValue': '${e.value}'}
                : e.value is List
                    ? {'arrayValue': (e.value as List).isEmpty ? {} : {'values': [for (final x in e.value as List) {'stringValue': '$x'}]}}
                    : {'stringValue': '${e.value}'}
        }
      };

  static dynamic _dec(Map v) {
    if (v.containsKey('integerValue')) return int.parse('${v['integerValue']}');
    if (v.containsKey('arrayValue')) return [for (final x in (((v['arrayValue'] as Map)['values'] ?? []) as List)) _dec(x as Map)];
    if (v.containsKey('timestampValue')) return v['timestampValue'];
    return v['stringValue'] ?? '';
  }

  static Future<Map<String, dynamic>?> pull() async {
    if (!cloud || user == null) return null;
    try {
      final tk = await fresh();
      final j = await _call('GET', '$_fs/users/${user!.uid}', token: tk, soft404: true);
      final f = j['fields'];
      if (f is! Map) return null;
      return {for (final e in f.entries) '${e.key}': _dec(e.value as Map)};
    } catch (_) {
      return null;
    }
  }

  static Future<bool> push(Map<String, dynamic> d) async {
    if (!cloud || user == null) return true;
    try {
      final tk = await fresh();
      await _call('PATCH', '$_fs/users/${user!.uid}', token: tk, body: _enc(d));
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<DateTime?> entitlement() async {
    if (!cloud || user == null) return null;
    try {
      final tk = await fresh();
      final j = await _call('GET', '$_fs/entitlements/${user!.uid}', token: tk, soft404: true);
      final f = j['fields'];
      if (f is Map && f['until'] is Map) return DateTime.tryParse('${(f['until'] as Map)['timestampValue']}');
    } catch (_) {}
    return null;
  }

  static Future<void> feedback(Map<String, dynamic> d) async {
    final tk = await fresh();
    await _call('POST', '$_fs/feedback', token: tk, body: _enc(d));
  }

  /// Lemon Squeezy hosted checkout (PCI-compliant). The uid travels as custom data
  /// so the webhook can credit the right account; prices/plans are fixed in the dashboard.
  static String checkoutUrl(int plan) {
    final base = checkoutBase(plan)!;
    final u = user!;
    return Uri.parse(base).replace(queryParameters: {'checkout[email]': u.email, 'checkout[custom][uid]': u.uid}).toString();
  }

  static Future<void> deleteAccount() async {
    final u = user;
    if (u == null) return;
    if (cloud) {
      final tk = await fresh();
      try { await _call('DELETE', '$_fs/users/${u.uid}', token: tk); } catch (_) {}
      await _call('POST', '$_idt:delete?key=$kApiKey', body: {'idToken': tk});
    } else {
      await _ss.delete(key: 'acc_${u.email.toLowerCase()}');
    }
    await signOut();
  }
}
