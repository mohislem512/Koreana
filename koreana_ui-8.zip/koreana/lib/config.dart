// Values are injected by the GitHub workflow from repository secrets.
const kApiKey = 'PASTE_API_KEY';
const kProjectId = 'PASTE_PROJECT_ID';
// Lemon Squeezy checkout links (one per plan: 1, 2, 3 months)
const kLsUrl1 = 'PASTE_LS_URL_1';
const kLsUrl2 = 'PASTE_LS_URL_2';
const kLsUrl3 = 'PASTE_LS_URL_3';
