import 'i18n.dart';

class W {
  final String ko, rom, ar, en, fr;
  const W(this.ko, this.rom, this.ar, this.en, this.fr);
  String get tr => [ar, en, fr][gLang];
}

const _vocab0 = <List<W>>[
  [
    W('안녕하세요', 'annyeonghaseyo', 'مرحبا', 'Hello', 'Bonjour'),
    W('감사합니다', 'gamsahamnida', 'شكرا', 'Thank you', 'Merci'),
    W('네', 'ne', 'نعم', 'Yes', 'Oui'),
    W('아니요', 'aniyo', 'لا', 'No', 'Non'),
    W('죄송합니다', 'joesonghamnida', 'آسف', 'Sorry', 'Désolé'),
    W('사랑', 'sarang', 'حب', 'Love', 'Amour'),
    W('물', 'mul', 'ماء', 'Water', 'Eau'),
    W('밥', 'bap', 'أرز / وجبة', 'Rice / meal', 'Riz / repas'),
    W('학교', 'hakgyo', 'مدرسة', 'School', 'École'),
    W('친구', 'chingu', 'صديق', 'Friend', 'Ami'),
    W('엄마', 'eomma', 'أمي', 'Mom', 'Maman'),
    W('아빠', 'appa', 'أبي', 'Dad', 'Papa'),
  ],
  [
    W('하나', 'hana', 'واحد', 'One', 'Un'),
    W('둘', 'dul', 'اثنان', 'Two', 'Deux'),
    W('셋', 'set', 'ثلاثة', 'Three', 'Trois'),
    W('오늘', 'oneul', 'اليوم', 'Today', 'Aujourd’hui'),
    W('내일', 'naeil', 'غدا', 'Tomorrow', 'Demain'),
    W('커피', 'keopi', 'قهوة', 'Coffee', 'Café'),
    W('집', 'jip', 'بيت', 'House', 'Maison'),
    W('책', 'chaek', 'كتاب', 'Book', 'Livre'),
    W('좋아요', 'joayo', 'جيد', 'Good', 'Bien'),
    W('얼마예요?', 'eolmayeyo', 'كم السعر؟', 'How much?', 'Combien ?'),
  ],
  [
    W('지하철', 'jihacheol', 'مترو', 'Subway', 'Métro'),
    W('병원', 'byeongwon', 'مستشفى', 'Hospital', 'Hôpital'),
    W('시장', 'sijang', 'سوق', 'Market', 'Marché'),
    W('비싸요', 'bissayo', 'غالٍ', 'Expensive', 'Cher'),
    W('맛있어요', 'masisseoyo', 'لذيذ', 'Delicious', 'Délicieux'),
    W('어디예요?', 'eodiyeyo', 'أين؟', 'Where is it?', 'C’est où ?'),
    W('도와주세요', 'dowajuseyo', 'ساعدني', 'Help me', 'Aidez-moi'),
    W('공항', 'gonghang', 'مطار', 'Airport', 'Aéroport'),
  ],
  [
    W('경험', 'gyeongheom', 'تجربة', 'Experience', 'Expérience'),
    W('문화', 'munhwa', 'ثقافة', 'Culture', 'Culture'),
    W('약속', 'yaksok', 'موعد / وعد', 'Appointment / promise', 'Rendez-vous / promesse'),
    W('환경', 'hwangyeong', 'بيئة', 'Environment', 'Environnement'),
    W('건강', 'geongang', 'صحة', 'Health', 'Santé'),
    W('여행', 'yeohaeng', 'سفر', 'Travel', 'Voyage'),
    W('취미', 'chwimi', 'هواية', 'Hobby', 'Passe-temps'),
    W('계획', 'gyehoek', 'خطة', 'Plan', 'Plan'),
  ],
  [
    W('궁궐', 'gunggwol', 'قصر ملكي', 'Royal palace', 'Palais royal'),
    W('전통', 'jeontong', 'تقاليد', 'Tradition', 'Tradition'),
    W('소통', 'sotong', 'تواصل', 'Communication', 'Communication'),
    W('성취', 'seongchwi', 'إنجاز', 'Achievement', 'Accomplissement'),
    W('도전', 'dojeon', 'تحدٍّ', 'Challenge', 'Défi'),
    W('존경', 'jongyeong', 'احترام', 'Respect', 'Respect'),
    W('책임', 'chaegim', 'مسؤولية', 'Responsibility', 'Responsabilité'),
    W('노력', 'noryeok', 'جهد', 'Effort', 'Effort'),
  ],
];

const _reading0 = <List<W>>[
  [
    W('저는 학생이에요.', '', 'أنا طالب.', 'I am a student.', 'Je suis étudiant.'),
    W('이것은 책이에요.', '', 'هذا كتاب.', 'This is a book.', 'C’est un livre.'),
  ],
  [
    W('오늘은 날씨가 좋아요.', '', 'الطقس جيد اليوم.', 'The weather is nice today.', 'Il fait beau aujourd’hui.'),
    W('저는 커피를 마셔요.', '', 'أنا أشرب القهوة.', 'I drink coffee.', 'Je bois du café.'),
  ],
  [
    W('저는 지하철을 타고 학교에 가요.', '', 'أركب المترو وأذهب إلى المدرسة.', 'I take the subway to school.', 'Je prends le métro pour aller à l’école.'),
    W('시장에서 과일을 사요.', '', 'أشتري الفاكهة من السوق.', 'I buy fruit at the market.', 'J’achète des fruits au marché.'),
  ],
  [
    W('주말에 친구와 여행을 가고 싶어요.', '', 'أريد السفر مع صديقي في عطلة نهاية الأسبوع.', 'I want to travel with a friend on the weekend.', 'Je veux voyager avec un ami ce week-end.'),
    W('건강을 위해 매일 운동해요.', '', 'أمارس الرياضة كل يوم من أجل صحتي.', 'I exercise every day for my health.', 'Je fais du sport tous les jours pour ma santé.'),
  ],
  [
    W('한국의 전통 문화는 오랜 역사 속에서 발전해 왔습니다.', '', 'تطورت الثقافة الكورية التقليدية عبر تاريخ طويل.', 'Korea’s traditional culture has developed over a long history.', 'La culture traditionnelle coréenne s’est développée au fil d’une longue histoire.'),
    W('꾸준한 노력은 반드시 좋은 결과를 가져옵니다.', '', 'الجهد المستمر يجلب نتائج جيدة حتما.', 'Steady effort will surely bring good results.', 'Un effort constant apporte sûrement de bons résultats.'),
  ],
];

class Turn {
  final W bot;
  final List<W> replies;
  const Turn(this.bot, this.replies);
}

const chatScripts = <List<Turn>>[
  [
    Turn(W('안녕하세요! 이름이 뭐예요?', 'annyeonghaseyo! ireumi mwoyeyo?', 'مرحبا! ما اسمك؟', 'Hello! What’s your name?', 'Bonjour ! Comment vous appelez-vous ?'), [
      W('제 이름은 민수예요.', 'je ireumeun minsuyeyo', 'اسمي مينسو.', 'My name is Minsu.', 'Je m’appelle Minsu.'),
      W('안녕하세요! 만나서 반가워요.', 'annyeonghaseyo! mannaseo bangawoyo', 'مرحبا! سررت بلقائك.', 'Hello! Nice to meet you.', 'Bonjour ! Enchanté.'),
    ]),
    Turn(W('어느 나라에서 왔어요?', 'eoneu naraeseo wasseoyo?', 'من أي بلد أنت؟', 'Which country are you from?', 'Vous venez de quel pays ?'), [
      W('저는 알제리에서 왔어요.', 'jeoneun aljeoriaeseo wasseoyo', 'أنا من الجزائر.', 'I’m from Algeria.', 'Je viens d’Algérie.'),
      W('저는 프랑스에서 왔어요.', 'jeoneun peurangseueseo wasseoyo', 'أنا من فرنسا.', 'I’m from France.', 'Je viens de France.'),
    ]),
    Turn(W('한국어를 좋아해요?', 'hangugeoreul joahaeyo?', 'هل تحب اللغة الكورية؟', 'Do you like Korean?', 'Vous aimez le coréen ?'), [
      W('네, 정말 좋아해요!', 'ne, jeongmal joahaeyo', 'نعم، أحبها كثيرا!', 'Yes, I really like it!', 'Oui, je l’adore !'),
      W('조금 어려워요.', 'jogeum eoryeowoyo', 'صعبة قليلا.', 'It’s a bit difficult.', 'C’est un peu difficile.'),
    ]),
  ],
  [
    Turn(W('주말에 보통 뭐 해요?', 'jumare botong mwo haeyo?', 'ماذا تفعل عادة في عطلة نهاية الأسبوع؟', 'What do you usually do on weekends?', 'Que faites-vous d’habitude le week-end ?'), [
      W('친구를 만나요.', 'chingureul mannayo', 'ألتقي بأصدقائي.', 'I meet my friends.', 'Je retrouve mes amis.'),
      W('집에서 쉬어요.', 'jibeseo swieoyo', 'أرتاح في البيت.', 'I rest at home.', 'Je me repose à la maison.'),
    ]),
    Turn(W('한국에 가 보고 싶어요?', 'hanguge ga bogo sipeoyo?', 'هل تريد زيارة كوريا؟', 'Do you want to visit Korea?', 'Vous voulez visiter la Corée ?'), [
      W('네, 꼭 가고 싶어요.', 'ne, kkok gago sipeoyo', 'نعم، أريد الذهاب بالتأكيد.', 'Yes, I definitely want to go.', 'Oui, j’ai très envie d’y aller.'),
      W('아직 모르겠어요.', 'ajik moreugesseoyo', 'لا أعرف بعد.', 'I don’t know yet.', 'Je ne sais pas encore.'),
    ]),
    Turn(W('한국 음식 중에서 뭐가 제일 맛있어요?', 'hanguk eumsik jungeseo mwoga jeil masisseoyo?', 'ما ألذ طعام كوري؟', 'Which Korean food is the tastiest?', 'Quel plat coréen est le meilleur ?'), [
      W('김치찌개가 제일 맛있어요.', 'gimchijjigaega jeil masisseoyo', 'حساء الكيمتشي ألذ شيء.', 'Kimchi stew is the tastiest.', 'Le ragoût de kimchi est le meilleur.'),
      W('비빔밥을 좋아해요.', 'bibimbabeul joahaeyo', 'أحب البيبيمباب.', 'I like bibimbap.', 'J’aime le bibimbap.'),
    ]),
  ],
];

final List<List<W>> vocab = [for (final l in _vocab0) [...l]];
final List<List<W>> reading = [for (final l in _reading0) [...l]];
