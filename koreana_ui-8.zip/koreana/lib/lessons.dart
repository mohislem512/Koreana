import 'data.dart';

class Lesson {
  final List<String> title, body;
  final List<W> ex;
  const Lesson(this.title, this.body, this.ex);
}

const lessons = <List<Lesson>>[
  [
    Lesson(['الحروف الكورية (한글)', 'Hangul basics', 'Bases du hangeul'], [
      'الهانغول فيه 14 حرفا ساكنا و10 حروف علة أساسية. ㅏ = a ، ㅣ = i ، ㅗ = o ، ㅜ = u ، ㄱ = g/k ، ㄴ = n ، ㅁ = m. تُجمع الحروف في مقاطع مثل 나 (na) و 마 (ma).',
      'Hangul has 14 basic consonants and 10 basic vowels. ㅏ = a, ㅣ = i, ㅗ = o, ㅜ = u, ㄱ = g/k, ㄴ = n, ㅁ = m. Letters combine into blocks like 나 (na) and 마 (ma).',
      'Le hangeul compte 14 consonnes et 10 voyelles de base. ㅏ = a, ㅣ = i, ㅗ = o, ㅜ = u, ㄱ = g/k, ㄴ = n, ㅁ = m. Les lettres forment des blocs comme 나 (na) et 마 (ma).'
    ], [
      W('나', 'na', 'أنا (غير رسمي)', 'I / me (casual)', 'moi (familier)'),
      W('아이', 'ai', 'طفل', 'Child', 'Enfant'),
      W('우유', 'uyu', 'حليب', 'Milk', 'Lait'),
    ]),
    Lesson(['الأدب في الكلام (요)', 'Polite endings (요)', 'Politesse (요)'], [
      'إضافة 요 في نهاية الجملة تجعلها مهذبة، وهي الصيغة المناسبة للحياة اليومية. مثال: 주세요 = من فضلك أعطني.',
      'Adding 요 to the end of a sentence makes it polite — the standard style for daily life. Example: 주세요 = please give me.',
      'Ajouter 요 en fin de phrase la rend polie : c’est le registre courant. Exemple : 주세요 = donnez-moi, s’il vous plaît.'
    ], [
      W('물 주세요', 'mul juseyo', 'ماء من فضلك', 'Water, please', 'De l’eau, s’il vous plaît'),
      W('좋아요', 'joayo', 'جيد / أحب', 'Good / I like it', 'Bien / j’aime'),
    ]),
  ],
  [
    Lesson(['فعل الكينونة 이에요/예요', 'To be: 이에요/예요', 'Être : 이에요/예요'], [
      'نضيف 이에요 بعد اسم ينتهي بحرف ساكن، و 예요 بعد اسم ينتهي بحرف علة. 학생이에요 = أنا/هو طالب، 의사예요 = طبيب.',
      'Add 이에요 after a noun ending in a consonant and 예요 after a vowel. 학생이에요 = (I am) a student, 의사예요 = a doctor.',
      'On ajoute 이에요 après une consonne et 예요 après une voyelle. 학생이에요 = (je suis) étudiant, 의사예요 = médecin.'
    ], [
      W('학생이에요', 'haksaengieyo', 'طالب', 'a student', 'étudiant'),
      W('의사예요', 'uisayeyo', 'طبيب', 'a doctor', 'médecin'),
    ]),
    Lesson(['الأرقام', 'Numbers', 'Les nombres'], [
      'للعدّ نستخدم 하나 둘 셋ـ(للأشياء)، وللتواريخ والأسعار 일 이 삼.',
      'Native numbers 하나, 둘, 셋 count objects; Sino numbers 일, 이, 삼 are for dates and prices.',
      'Les nombres natifs 하나, 둘, 셋 comptent les objets ; les nombres sino-coréens 일, 이, 삼 servent aux dates et aux prix.'
    ], [
      W('일', 'il', 'واحد (أسعار/تواريخ)', 'one (dates/prices)', 'un (dates/prix)'),
      W('이', 'i', 'اثنان', 'two', 'deux'),
      W('삼', 'sam', 'ثلاثة', 'three', 'trois'),
    ]),
  ],
  [
    Lesson(['أدوات الموضوع والفاعل 은/는 · 이/가', 'Particles 은/는 and 이/가', 'Particules 은/는 et 이/가'], [
      '은/는 تحدد الموضوع، و이/가 تحدد الفاعل. 은 و이 بعد حرف ساكن، و는 و가 بعد حرف علة.',
      '은/는 marks the topic and 이/가 marks the subject. 은 and 이 follow a consonant; 는 and 가 follow a vowel.',
      '은/는 marque le thème et 이/가 le sujet. 은 et 이 après une consonne ; 는 et 가 après une voyelle.'
    ], [
      W('저는 학생이에요.', 'jeoneun haksaengieyo', 'أنا طالب.', 'I am a student.', 'Je suis étudiant.'),
      W('비가 와요.', 'biga wayo', 'تمطر.', 'It rains.', 'Il pleut.'),
    ]),
    Lesson(['الماضي ـ았/었어요', 'Past tense -았/었어요', 'Passé -았/었어요'], [
      'للماضي: جذر الفعل + 았어요 إذا كان آخر حرف علة فيه ㅏ أو ㅗ، وإلا + 었어요.',
      'Past tense: verb stem + 았어요 if the last vowel is ㅏ or ㅗ, otherwise + 었어요.',
      'Passé : radical + 았어요 si la dernière voyelle est ㅏ ou ㅗ, sinon + 었어요.'
    ], [
      W('먹었어요', 'meogeosseoyo', 'أكلت', 'I ate', 'J’ai mangé'),
      W('갔어요', 'gasseoyo', 'ذهبت', 'I went', 'Je suis allé'),
    ]),
  ],
  [
    Lesson(['التعبير عن الرغبة ـ고 싶어요', 'Wanting: -고 싶어요', 'Vouloir : -고 싶어요'], [
      'جذر الفعل + 고 싶어요 = أريد أن... مثال: 가고 싶어요 = أريد الذهاب.',
      'Verb stem + 고 싶어요 = I want to... Example: 가고 싶어요 = I want to go.',
      'Radical + 고 싶어요 = je veux... Exemple : 가고 싶어요 = je veux y aller.'
    ], [
      W('가고 싶어요', 'gago sipeoyo', 'أريد الذهاب', 'I want to go', 'Je veux y aller'),
      W('먹고 싶어요', 'meokgo sipeoyo', 'أريد أن آكل', 'I want to eat', 'Je veux manger'),
    ]),
    Lesson(['المستقبل ـ(으)ㄹ 거예요', 'Future: -(으)ㄹ 거예요', 'Futur : -(으)ㄹ 거예요'], [
      'للمستقبل: الجذر + ㄹ 거예요 بعد حرف علة، و 을 거예요 بعد حرف ساكن.',
      'Future: stem + ㄹ 거예요 after a vowel, 을 거예요 after a consonant.',
      'Futur : radical + ㄹ 거예요 après voyelle, 을 거예요 après consonne.'
    ], [
      W('갈 거예요', 'gal geoyeyo', 'سأذهب', 'I will go', 'J’irai'),
      W('먹을 거예요', 'meogeul geoyeyo', 'سآكل', 'I will eat', 'Je mangerai'),
    ]),
  ],
  [
    Lesson(['صيغة الاحترام ـ(으)시', 'Honorific -(으)시-', 'Honorifique -(으)시-'], [
      'لاحترام الأكبر سنا نضيف 시 بعد جذر الفعل: 오다 ← 오세요، 가다 ← 가세요.',
      'To honor someone senior, insert 시 after the verb stem: 오다 → 오세요, 가다 → 가세요.',
      'Pour respecter un aîné, insérez 시 après le radical : 오다 → 오세요, 가다 → 가세요.'
    ], [
      W('선생님이 오세요.', 'seonsaengnimi oseyo', 'المعلم قادم.', 'The teacher is coming.', 'Le professeur arrive.'),
    ]),
    Lesson(['الكلام المنقول ـ다고 해요', 'Reported speech -다고 해요', 'Discours rapporté -다고 해요'], [
      'لنقل كلام الغير: الجملة + 다고 해요 = يقولون إن... مثال: 비가 온다고 해요 = يقولون إنها ستمطر.',
      'To report speech: clause + 다고 해요 = they say that... Example: 비가 온다고 해요 = they say it will rain.',
      'Pour rapporter : proposition + 다고 해요 = on dit que... Exemple : 비가 온다고 해요 = on dit qu’il va pleuvoir.'
    ], [
      W('비가 온다고 해요.', 'biga ondago haeyo', 'يقولون إنها ستمطر.', 'They say it will rain.', 'On dit qu’il va pleuvoir.'),
    ]),
  ],
];

const moreLessons = <List<Lesson>>[
  [
    Lesson(['ترتيب الجملة (فاعل–مفعول–فعل)', 'Word order (S–O–V)', 'Ordre des mots (S–O–V)'], [
      'في الكورية يأتي الفعل دائما في آخر الجملة: الفاعل + المفعول + الفعل. مثال: 저는 밥을 먹어요 = أنا (الأرز) آكل.',
      'In Korean the verb always comes last: subject + object + verb. Example: 저는 밥을 먹어요 = I (rice) eat.',
      'En coréen le verbe est toujours à la fin : sujet + objet + verbe. Exemple : 저는 밥을 먹어요 = Je (riz) mange.'
    ], [
      W('저는 물을 마셔요.', 'jeoneun mureul masyeoyo', 'أنا أشرب الماء.', 'I drink water.', 'Je bois de l’eau.'),
    ]),
    Lesson(['أداة المفعول 을/를', 'Object particle 을/를', 'Particule d’objet 을/를'], [
      'تُضاف 을 بعد اسم ينتهي بحرف ساكن، و를 بعد اسم ينتهي بحرف علة، للدلالة على المفعول به. 물을 마셔요، 커피를 마셔요.',
      'Add 을 after a noun ending in a consonant and 를 after a vowel to mark the object. 물을 마셔요, 커피를 마셔요.',
      'Ajoutez 을 après une consonne et 를 après une voyelle pour marquer l’objet. 물을 마셔요, 커피를 마셔요.'
    ], [
      W('커피를 마셔요.', 'keopireul masyeoyo', 'أشرب القهوة.', 'I drink coffee.', 'Je bois du café.'),
      W('책을 읽어요.', 'chaegeul ilgeoyo', 'أقرأ كتابا.', 'I read a book.', 'Je lis un livre.'),
    ]),
  ],
  [
    Lesson(['النفي: 안 و ـ지 않아요', 'Negation: 안 and -지 않아요', 'Négation : 안 et -지 않아요'], [
      'ضع 안 قبل الفعل، أو أضف 지 않아요 بعد الجذر. 안 가요 = لا أذهب، 먹지 않아요 = لا آكل.',
      'Put 안 before the verb, or add 지 않아요 after the stem. 안 가요 = I don’t go, 먹지 않아요 = I don’t eat.',
      'Placez 안 devant le verbe ou ajoutez 지 않아요 après le radical. 안 가요 = je ne vais pas, 먹지 않아요 = je ne mange pas.'
    ], [
      W('안 가요.', 'an gayo', 'لا أذهب.', 'I don’t go.', 'Je n’y vais pas.'),
      W('먹지 않아요.', 'meokji anayo', 'لا آكل.', 'I don’t eat.', 'Je ne mange pas.'),
    ]),
    Lesson(['أدوات المكان 에 و 에서', 'Place particles 에 and 에서', 'Particules de lieu 에 et 에서'], [
      '에 للوجهة وللمكان الموجود فيه شيء (أذهب إلى / يوجد في)، و에서 للمكان الذي يحدث فيه الفعل.',
      '에 marks a destination or location of existence; 에서 marks where an action takes place.',
      '에 marque la destination ou le lieu d’existence ; 에서 le lieu où se déroule l’action.'
    ], [
      W('학교에 가요.', 'hakgyoe gayo', 'أذهب إلى المدرسة.', 'I go to school.', 'Je vais à l’école.'),
      W('학교에서 공부해요.', 'hakgyoeseo gongbuhaeyo', 'أدرس في المدرسة.', 'I study at school.', 'J’étudie à l’école.'),
    ]),
  ],
  [
    Lesson(['الطلب المهذب ـ아/어 주세요', 'Polite requests -아/어 주세요', 'Demandes polies -아/어 주세요'], [
      'جذر الفعل + 아/어 주세요 = من فضلك افعل لي كذا. 도와 주세요 = ساعدني، 기다려 주세요 = انتظر من فضلك.',
      'Verb stem + 아/어 주세요 = please do … for me. 도와 주세요 = help me, 기다려 주세요 = please wait.',
      'Radical + 아/어 주세요 = faites-moi … s’il vous plaît. 도와 주세요 = aidez-moi, 기다려 주세요 = attendez, s’il vous plaît.'
    ], [
      W('말해 주세요.', 'malhae juseyo', 'قل لي من فضلك.', 'Please tell me.', 'Dites-le-moi, s’il vous plaît.'),
      W('기다려 주세요.', 'gidaryeo juseyo', 'انتظر من فضلك.', 'Please wait.', 'Attendez, s’il vous plaît.'),
    ]),
    Lesson(['السماح والمنع', 'Permission and prohibition', 'Permission et interdiction'], [
      '아/어도 돼요 = يمكنك/يجوز. (으)면 안 돼요 = لا يجوز. 앉아도 돼요? هل يمكنني الجلوس؟ 들어가면 안 돼요 = لا تدخل.',
      '아/어도 돼요 = you may. (으)면 안 돼요 = you must not. 앉아도 돼요? May I sit? 들어가면 안 돼요 = you can’t go in.',
      '아/어도 돼요 = vous pouvez. (으)면 안 돼요 = il est interdit de. 앉아도 돼요 ? Puis-je m’asseoir ? 들어가면 안 돼요 = n’entrez pas.'
    ], [
      W('앉아도 돼요?', 'anjado dwaeyo', 'هل يمكنني الجلوس؟', 'May I sit?', 'Puis-je m’asseoir ?'),
      W('들어가면 안 돼요.', 'deureogamyeon an dwaeyo', 'لا يجوز الدخول.', 'You must not enter.', 'Il est interdit d’entrer.'),
    ]),
  ],
  [
    Lesson(['السبب: ـ아/어서 و ـ(으)니까', 'Reasons: -아/어서 and -(으)니까', 'Cause : -아/어서 et -(으)니까'], [
      '아/어서 تعبر عن سبب ونتيجة (لا تأتي معها أوامر)، و(으)니까 تعبر عن السبب مع الأمر أو الاقتراح. 피곤해서 잤어요. 비가 오니까 우산을 가져가세요.',
      '아/어서 gives a reason–result link (no commands after it); (으)니까 gives a reason that can be followed by commands or suggestions. 피곤해서 잤어요. 비가 오니까 우산을 가져가세요.',
      '아/어서 relie cause et conséquence (pas d’ordre ensuite) ; (으)니까 donne une raison qui peut être suivie d’un ordre ou d’une suggestion. 피곤해서 잤어요. 비가 오니까 우산을 가져가세요.'
    ], [
      W('피곤해서 잤어요.', 'pigonhaeseo jasseoyo', 'نمت لأنني متعب.', 'I slept because I was tired.', 'J’ai dormi parce que j’étais fatigué.'),
    ]),
    Lesson(['الشرط والتناقض', 'Conditions and contrast', 'Condition et contraste'], [
      '(으)면 = إذا، و지만 = لكن. 시간이 있으면 같이 가요. 어렵지만 재미있어요.',
      '(으)면 = if, 지만 = but. 시간이 있으면 같이 가요. 어렵지만 재미있어요.',
      '(으)면 = si, 지만 = mais. 시간이 있으면 같이 가요. 어렵지만 재미있어요.'
    ], [
      W('어렵지만 재미있어요.', 'eoryeopjiman jaemiisseoyo', 'صعب لكنه ممتع.', 'It’s hard but fun.', 'C’est difficile mais amusant.'),
    ]),
  ],
  [
    Lesson(['النهايات الرسمية ـㅂ니다/습니다', 'Formal endings -ㅂ니다/습니다', 'Terminaisons formelles -ㅂ니다/습니다'], [
      'للمواقف الرسمية (أخبار، عمل، خطابات): الجذر + ㅂ니다 بعد حرف علة، و습니다 بعد حرف ساكن. 감사합니다، 먹습니다.',
      'For formal situations (news, work, speeches): stem + ㅂ니다 after a vowel, 습니다 after a consonant. 감사합니다, 먹습니다.',
      'Pour les situations formelles (infos, travail, discours) : radical + ㅂ니다 après voyelle, 습니다 après consonne. 감사합니다, 먹습니다.'
    ], [
      W('발표를 시작하겠습니다.', '', 'سأبدأ العرض.', 'I will begin the presentation.', 'Je vais commencer la présentation.'),
    ]),
    Lesson(['الأمثال الكورية 속담', 'Korean proverbs 속담', 'Proverbes coréens 속담'], [
      'الأمثال جزء أساسي من الكلام الكوري. تعلّم المعنى والسياق: 시작이 반이다 تُقال لتشجيع من يبدأ عملا.',
      'Proverbs are a core part of spoken Korean. Learn meaning and context: 시작이 반이다 encourages someone who is starting something.',
      'Les proverbes font partie intégrante du coréen parlé. Apprenez sens et contexte : 시작이 반이다 encourage celui qui commence.'
    ], [
      W('시작이 반이다.', 'sijagi banida', 'البداية نصف الطريق.', 'Well begun is half done.', 'Un bon début, c’est la moitié du travail.'),
    ]),
  ],
];
