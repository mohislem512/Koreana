import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'auth.dart';
import 'batch_a.dart';
import 'content.dart';
import 'screens.dart';
import 'skills.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Content.load();
  await AppState.i.boot();
  runApp(const KoreanaApp());
}

class KoreanaApp extends StatelessWidget {
  const KoreanaApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: AppState.i.langV,
        builder: (_, l, __) => MaterialApp(
          key: ValueKey(l),
          title: 'Koreana',
          debugShowCheckedModeBanner: false,
          navigatorKey: AppState.i.nav,
          scaffoldMessengerKey: AppState.i.msgKey,
          theme: KTheme.build(),
          themeMode: ThemeMode.dark,
          locale: Locale(['ar', 'en', 'fr'][l]),
          supportedLocales: const [Locale('ar'), Locale('en'), Locale('fr')],
          localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
          builder: (ctx, child) => ListenableBuilder(
            listenable: AppState.i,
            builder: (_, __) => Stack(fit: StackFit.expand, children: [KBackground(AppState.i.level), child!]),
          ),
          initialRoute: Auth.user == null ? '/' : (AppState.i.onb ? '/home' : '/levels'),
          routes: {
            '/': (_) => const WelcomeScreen(),
            '/auth': (_) => const AuthScreen(),
            '/levels': (_) => const LevelScreen(),
            '/home': (_) => const HomeShell(),
            '/reading': (_) => const ReadingScreen(),
            '/listening': (_) => const ListeningScreen(),
            '/pronounce': (_) => const PronounceScreen(),
            '/chat': (_) => const ChatScreen(),
            '/vocab': (_) => const VocabScreen(),
            '/builder': (_) => const BuilderScreen(),
            '/notebook': (_) => const NotebookScreen(),
            '/etiquette': (_) => const EtiquetteScreen(),
            '/plan': (_) => const PlanScreen(),
            '/drill': (_) => const DrillScreen(),
          },
        ),
      );
}
