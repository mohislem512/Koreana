// Approximate Revised Romanization of Hangul (liaison + basic nasalization).
const _ini = ['g', 'kk', 'n', 'd', 'tt', 'r', 'm', 'b', 'pp', 's', 'ss', '', 'j', 'jj', 'ch', 'k', 't', 'p', 'h'];
const _vow = ['a', 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa', 'wae', 'oe', 'yo', 'u', 'wo', 'we', 'wi', 'yu', 'eu', 'ui', 'i'];
const _fin = ['', 'k', 'k', 'k', 'n', 'n', 'n', 't', 'l', 'k', 'm', 'l', 'l', 'l', 'p', 'l', 'm', 'p', 'p', 't', 't', 'ng', 't', 't', 'k', 't', 'p', 't'];
// final -> [part that stays, initial index that moves to a following vowel (-1 = silent)]
const _lia = <int, List<Object>>{
  1: ['', 0], 2: ['', 1], 3: ['k', 9], 4: ['', 2], 5: ['n', 12], 6: ['', 2], 7: ['', 3], 8: ['', 5],
  9: ['l', 0], 10: ['l', 6], 11: ['l', 7], 12: ['l', 9], 13: ['l', 16], 14: ['l', 17], 15: ['', 5],
  16: ['', 6], 17: ['', 7], 18: ['p', 9], 19: ['', 9], 20: ['', 10], 22: ['', 12], 23: ['', 14],
  24: ['', 15], 25: ['', 16], 26: ['', 17], 27: ['', -1],
};

bool _hg(int r) => r >= 0xAC00 && r <= 0xD7A3;

String romanize(String s) {
  final rs = s.runes.toList();
  final out = StringBuffer();
  String? ov;
  var prev = '';
  for (var i = 0; i < rs.length; i++) {
    final r = rs[i];
    if (!_hg(r)) {
      out.writeCharCode(r);
      prev = '';
      ov = null;
      continue;
    }
    final c = r - 0xAC00;
    final ini = c ~/ 588, vow = (c % 588) ~/ 28, fin = c % 28;
    var iniS = ov ?? _ini[ini];
    ov = null;
    if (ini == 5 && prev == 'l') iniS = 'l';
    final n = (i + 1 < rs.length && _hg(rs[i + 1])) ? (rs[i + 1] - 0xAC00) ~/ 588 : null;
    var finS = '';
    String? moved;
    if (fin != 0) {
      if (n == 11 && _lia.containsKey(fin)) {
        final l = _lia[fin]!;
        finS = l[0] as String;
        final m = l[1] as int;
        moved = m >= 0 ? _ini[m] : '';
      } else {
        finS = _fin[fin];
        if (n == 2 || n == 6) {
          if (finS == 'k') finS = 'ng';
          else if (finS == 't') finS = 'n';
          else if (finS == 'p') finS = 'm';
        }
      }
    }
    out..write(iniS)..write(_vow[vow])..write(finS);
    ov = moved;
    prev = n == 11 ? '' : finS;
  }
  return out.toString();
}
