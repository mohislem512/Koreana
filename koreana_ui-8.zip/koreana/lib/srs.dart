import 'dart:math';
import 'data.dart';
import 'state.dart';

/// Spaced repetition (Leitner boxes): no immediate repeats, new items are
/// mixed with items that are due for review; wrong answers come back sooner.
class Srs {
  static final _r = Random();
  static final List<String> _recent = [];
  static const _minutes = [0, 10, 1440, 4320, 10080, 20160];

  static int box(W w) => AppState.i.srs[w.ko]?[0] ?? -1;
  static int learned(List<W> pool) => pool.where((w) => box(w) >= 3).length;

  static W next(List<W> pool) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final s = AppState.i.srs;
    List<W> cand(bool Function(W) f) => pool.where((w) => f(w) && !_recent.contains(w.ko)).toList();
    final fresh = cand((w) => !s.containsKey(w.ko));
    final due = cand((w) => s.containsKey(w.ko) && s[w.ko]![1] <= now);
    List<W> pick;
    if (due.isNotEmpty && (fresh.isEmpty || _r.nextDouble() < .4)) {
      pick = due;
    } else if (fresh.isNotEmpty) {
      pick = fresh;
    } else {
      final rest = pool.where((w) => !_recent.contains(w.ko)).toList()
        ..sort((a, b) => (s[a.ko]?[1] ?? 0).compareTo(s[b.ko]?[1] ?? 0));
      pick = rest.isEmpty ? pool : rest.take(5).toList();
    }
    final w = pick[_r.nextInt(pick.length)];
    _recent.add(w.ko);
    final keep = min(12, max(1, pool.length ~/ 2));
    while (_recent.length > keep) { _recent.removeAt(0); }
    return w;
  }

  static void grade(W w, bool ok) {
    final cur = box(w);
    final b = ok ? min(5, (cur < 0 ? 0 : cur) + 1) : 0;
    final wrong = (AppState.i.srs[w.ko]?.length ?? 0) > 2 ? AppState.i.srs[w.ko]![2] : 0;
    AppState.i.srs[w.ko] = [b, DateTime.now().millisecondsSinceEpoch + _minutes[b] * 60000, ok ? wrong : wrong + 1];
    AppState.i.saveSrs();
  }

  /// A mistake was corrected in the notebook.
  static void fix(W w) {
    final e = AppState.i.srs[w.ko];
    if (e == null) return;
    final wrong = e.length > 2 ? e[2] : 0;
    final b = min(5, e[0] + 1);
    AppState.i.srs[w.ko] = [b, DateTime.now().millisecondsSinceEpoch + _minutes[b] * 60000, max(0, wrong - 1)];
    AppState.i.saveSrs();
  }

  static int wrongCount(W w) => (AppState.i.srs[w.ko]?.length ?? 0) > 2 ? AppState.i.srs[w.ko]![2] : 0;

  /// Words/sentences answered wrong at least once and not yet fixed.
  static List<W> mistakes() {
    final byKo = <String, W>{for (final l in vocab) for (final w in l) w.ko: w, for (final l in reading) for (final w in l) w.ko: w};
    final out = <W>[for (final e in AppState.i.srs.entries) if (e.value.length > 2 && e.value[2] > 0 && byKo.containsKey(e.key)) byKo[e.key]!];
    out.sort((a, b) => wrongCount(b).compareTo(wrongCount(a)));
    return out;
  }

  /// Items of the current level that are due for review now.
  static int dueNow() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final lv = AppState.i.level;
    return [...vocab[lv], ...reading[lv]].where((w) => AppState.i.srs[w.ko] != null && AppState.i.srs[w.ko]![1] <= now).length;
  }
}
