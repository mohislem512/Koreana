#!/bin/bash
cd "$(dirname "$0")/.."
flutter --version | head -2
flutter create . --org com.koreana --project-name koreana
rm -rf test
python3 tool/patch_android.py
flutter pub get
dart run flutter_launcher_icons
flutter analyze --no-fatal-infos --no-fatal-warnings > analyze.log 2>&1 || true
echo "=========== DART ERRORS ==========="
grep -E " error " analyze.log | head -40
echo "=========== END ==========="
show() { grep -n -E "^e: |e: file|What went wrong|Caused by|Execution failed|Could not|error:|incompatible" -A3 "$1" | head -60; }
if flutter build apk --release > build.log 2>&1; then exit 0; fi
echo "=========== RELEASE FAILED ==========="
show build.log
echo "=========== TRYING DEBUG ==========="
flutter build apk --debug > build_debug.log 2>&1 || { show build_debug.log; exit 1; }
