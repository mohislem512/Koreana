import re, pathlib
m = pathlib.Path('android/app/src/main/AndroidManifest.xml')
s = m.read_text(encoding='utf8')
perms = '<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    '
intents = ('<intent><action android:name="android.speech.RecognitionService"/></intent>'
           '<intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>'
           '<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>')
if 'android.permission.INTERNET' not in s.replace('debug', ''):
    s = s.replace('<application', perms + '<application', 1)
if '<queries>' in s:
    s = s.replace('<queries>', '<queries>' + intents, 1)
else:
    s = s.replace('<application', '<queries>' + intents + '</queries>\n    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Koreana"', s, count=1)
m.write_text(s, encoding='utf8')
print('manifest patched')

# raise minSdk to 24 (required by flutter_tts and friends)
import os
for f in ['android/app/build.gradle', 'android/app/build.gradle.kts']:
    if os.path.exists(f):
        g = open(f, encoding='utf8').read()
        g2 = re.sub(r'(minSdk(?:Version)?\s*=?\s*)flutter\.minSdkVersion', r'\g<1>24', g)
        open(f, 'w', encoding='utf8').write(g2)
        print(f, 'minSdk patched' if g != g2 else 'minSdk line NOT found')
        for l in g2.splitlines():
            if 'minSdk' in l: print('  ', l.strip())
