import 'dart:math';
import 'package:flutter/material.dart';
import 'data.dart';
import 'i18n.dart';
import 'romanize.dart';
import 'srs.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

List<W> allWords() => [for (final l in vocab) ...l, for (final l in reading) ...l];

// =================== Sentence builder ===================
class BuilderScreen extends StatefulWidget {
  final List<W>? pool;
  const BuilderScreen({super.key, this.pool});
  @override
  State<BuilderScreen> createState() => _BuS();
}

class _BuS extends State<BuilderScreen> {
  final r = Random();
  late W cur;
  late List<String> tokens;
  final picked = <int>[];
  bool? ok;
  @override
  void initState() {
    super.initState();
    _new();
  }

  void _new() {
    final lvl = widget.pool ?? reading[AppState.i.level];
    final p = lvl.where((w) => w.ko.split(' ').length >= 3).toList();
    cur = Srs.next(p.isEmpty ? lvl : p);
    final orig = cur.ko.split(' ');
    tokens = [...orig];
    if (orig.toSet().length > 1) {
      var g = 0;
      do { tokens.shuffle(r); } while (tokens.join(' ') == cur.ko && g++ < 20);
    }
    picked.clear();
    ok = null;
  }

  void _check() {
    final good = picked.map((i) => tokens[i]).join(' ') == cur.ko;
    setState(() => ok = good);
    Srs.grade(cur, good);
    AppState.i.record('builder', good);
    if (good) {
      AppState.i.addXp(6, lesson: true);
      AppState.i.speak(cur.ko);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('builder'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Text(t('builderQ'), textAlign: TextAlign.center),
          const SizedBox(height: 10),
          KCard(child: Text(cur.tr, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
          const SizedBox(height: 12),
          KCard(
            padding: const EdgeInsets.all(14),
            child: SizedBox(
              width: double.infinity,
              child: Wrap(spacing: 8, runSpacing: 8, children: [
                for (final i in picked)
                  InputChip(label: Text(tokens[i], style: const TextStyle(fontSize: 20)), onPressed: ok == null ? () => setState(() => picked.remove(i)) : null),
                if (picked.isEmpty) const Text('…', style: TextStyle(color: Colors.white38)),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
            for (var i = 0; i < tokens.length; i++)
              ActionChip(
                label: Text(tokens[i], style: const TextStyle(fontSize: 20)),
                onPressed: (picked.contains(i) || ok != null) ? null : () => setState(() => picked.add(i)),
              ),
          ]),
          const SizedBox(height: 18),
          if (ok == null && picked.length == tokens.length) GradientButton(t('checkAnswer'), _check),
          if (ok != null) ...[
            Center(child: Text(ok! ? t('good') : t('wrongSentence'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
            const SizedBox(height: 6),
            Center(child: Text('${cur.ko}\n${cur.rom}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, height: 1.5))),
            const SizedBox(height: 12),
            GradientButton(t('next'), () => setState(_new)),
          ],
        ]),
      );
}

// =================== Mistake notebook ===================
class NotebookScreen extends StatefulWidget {
  const NotebookScreen({super.key});
  @override
  State<NotebookScreen> createState() => _NoS();
}

class _NoS extends State<NotebookScreen> {
  final r = Random();
  bool practice = false;
  W? q, pick;
  List<W> opts = [];

  void _newQ() {
    final m = Srs.mistakes();
    if (m.isEmpty) {
      practice = false;
      return;
    }
    q = m[r.nextInt(m.length)];
    final long = q!.ko.length > 8;
    final same = allWords().where((w) => (w.ko.length > 8) == long && w.ko != q!.ko).toList()..shuffle(r);
    opts = [q!, ...same.take(3)]..shuffle(r);
    pick = null;
  }

  @override
  Widget build(BuildContext context) {
    final m = Srs.mistakes();
    return Scaffold(
      appBar: AppBar(title: Text(t('notebook'))),
      body: practice && q != null
          ? ListView(padding: const EdgeInsets.all(16), children: [
              KCard(
                padding: const EdgeInsets.all(22),
                child: Column(children: [
                  Text(q!.ko, textAlign: TextAlign.center, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                  Text(q!.rom, style: const TextStyle(color: Colors.white54)),
                  IconButton(onPressed: () => AppState.i.speak(q!.ko), icon: const Icon(Icons.volume_up, color: KColors.primary)),
                ]),
              ),
              const SizedBox(height: 14),
              for (final w in opts)
                Opt(w.tr, pick == null ? 0 : (w == q ? 1 : (w == pick ? 2 : 0)), () {
                  if (pick != null) return;
                  setState(() => pick = w);
                  if (w == q) {
                    Srs.fix(q!);
                    AppState.i.addXp(4, lesson: true);
                  } else {
                    Srs.grade(q!, false);
                  }
                }),
              if (pick != null) GradientButton(t('next'), () => setState(_newQ)),
            ])
          : ListView(padding: const EdgeInsets.all(16), children: [
              if (m.isEmpty) Padding(padding: const EdgeInsets.all(40), child: Center(child: Text(t('mistakesEmpty'), style: const TextStyle(fontSize: 18)))),
              if (m.isNotEmpty) GradientButton(t('practiceMistakes'), () => setState(() { practice = true; _newQ(); })),
              const SizedBox(height: 10),
              for (final w in m)
                ListTile(
                  leading: const Icon(Icons.volume_up, color: KColors.primary),
                  title: Text(w.ko, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                  subtitle: Text('${w.rom}\n${w.tr}'),
                  isThreeLine: true,
                  trailing: Text('×${Srs.wrongCount(w)}', style: const TextStyle(color: KColors.orange, fontWeight: FontWeight.w800)),
                  onTap: () => AppState.i.speak(w.ko),
                ),
            ]),
    );
  }
}

// =================== Speech-level coach ===================
class Scn {
  final List<String> sit, mean, why, opts;
  final int ok;
  const Scn(this.sit, this.mean, this.opts, this.ok, this.why);
}

const scenarios = <Scn>[
  Scn(['تتكلم مع صديق مقرب في عمرك', 'Talking to a close friend your age', 'Vous parlez à un ami proche de votre âge'], ['هل أكلت؟', 'Did you eat?', 'Tu as mangé ?'], ['밥 먹었어?', '밥 먹었어요?', '식사하셨습니까?'], 0,
      ['مع الأصدقاء المقربين نستعمل الأسلوب غير الرسمي (بدون 요).', 'With close friends we use casual speech (no 요).', 'Entre amis proches, on utilise le familier (sans 요).']),
  Scn(['تطلب شيئا من بائع لا تعرفه', 'Asking a shop clerk you don’t know', 'Vous demandez quelque chose à un vendeur inconnu'], ['أعطني هذا من فضلك', 'Please give me this', 'Donnez-moi ça, s’il vous plaît'], ['이거 줘.', '이거 주세요.', '이것을 주십시오.'], 1,
      ['مع الغرباء في الحياة اليومية نستعمل الأسلوب المهذب (요).', 'With strangers in daily life we use polite speech (요).', 'Avec des inconnus au quotidien, on emploie le poli (요).']),
  Scn(['تتحدث أمام مدير الشركة في اجتماع رسمي', 'Speaking to your CEO in a formal meeting', 'Vous parlez devant le PDG en réunion formelle'], ['سأبدأ العرض', 'I will begin the presentation', 'Je vais commencer la présentation'], ['발표 시작할게.', '발표 시작할게요.', '발표를 시작하겠습니다.'], 2,
      ['في المواقف الرسمية نستعمل ـ합니다체.', 'In formal situations we use -합니다체.', 'En situation formelle on emploie le -합니다체.']),
  Scn(['تكلم أخاك الأصغر', 'Talking to your younger brother', 'Vous parlez à votre petit frère'], ['إلى أين تذهب؟', 'Where are you going?', 'Tu vas où ?'], ['어디 가?', '어디 가요?', '어디 가십니까?'], 0,
      ['مع الأصغر منك نستعمل الأسلوب غير الرسمي.', 'With someone younger we use casual speech.', 'Avec plus jeune que soi, on utilise le familier.']),
  Scn(['تسأل أستاذك في الجامعة إن كان سيأتي غدا', 'Asking your university professor if he will come tomorrow', 'Vous demandez à votre professeur s’il vient demain'], ['هل ستأتي غدا؟', 'Will you come tomorrow?', 'Viendrez-vous demain ?'], ['내일 와?', '내일 와요?', '내일 오세요?'], 2,
      ['للأستاذ نضيف ـ(으)시ـ للاحترام: 오다 ← 오세요.', 'For a professor add -(으)시- to show respect: 오다 → 오세요.', 'Pour un professeur, ajoutez -(으)시- : 오다 → 오세요.']),
  Scn(['نشرة أخبار الطقس', 'A weather forecast on the news', 'Un bulletin météo à la télévision'], ['ستمطر غدا', 'It will rain tomorrow', 'Il pleuvra demain'], ['내일 비가 와.', '내일 비가 와요.', '내일 비가 오겠습니다.'], 2,
      ['الأخبار والنشرات تستعمل الأسلوب الرسمي.', 'News broadcasts use the formal style.', 'Les journaux télévisés utilisent le style formel.']),
  Scn(['تقول لجدتك: تفضلي كلي كثيرا', 'Telling your grandmother: please eat a lot', 'Vous dites à votre grand-mère : mangez beaucoup'], ['كلي كثيرا', 'Eat a lot', 'Mangez beaucoup'], ['많이 먹어.', '많이 먹어요.', '많이 드세요.'], 2,
      ['للكبار نستعمل الفعل المحترم 드시다 (بدل 먹다).', 'For elders use the honorific verb 드시다 (instead of 먹다).', 'Pour les aînés, utilisez le verbe honorifique 드시다 (au lieu de 먹다).']),
];

class EtiquetteScreen extends StatefulWidget {
  const EtiquetteScreen({super.key});
  @override
  State<EtiquetteScreen> createState() => _EtS();
}

class _EtS extends State<EtiquetteScreen> {
  final r = Random();
  int idx = 0;
  int? pick;
  @override
  void initState() {
    super.initState();
    idx = r.nextInt(scenarios.length);
  }

  @override
  Widget build(BuildContext context) {
    final s = scenarios[idx];
    return Scaffold(
      appBar: AppBar(title: Text(t('etiquette'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        KCard(child: Text(t('etiqIntro'), style: const TextStyle(height: 1.6))),
        const SizedBox(height: 16),
        Text(t('etiqQ'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 8),
        KCard(
          color: const Color(0xFF22306E),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('🎭 ${s.sit[gLang]}', style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('“${s.mean[gLang]}”', style: const TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 12),
        for (var i = 0; i < 3; i++)
          Opt('${s.opts[i]}\n${romanize(s.opts[i])}', pick == null ? 0 : (i == s.ok ? 1 : (i == pick ? 2 : 0)), () {
            if (pick != null) return;
            setState(() => pick = i);
            AppState.i.record('etiquette', i == s.ok);
            if (i == s.ok) AppState.i.addXp(5, lesson: true);
            AppState.i.speak(s.opts[s.ok]);
          }),
        if (pick != null) ...[
          KCard(child: Text('💡 ${s.why[gLang]}')),
          const SizedBox(height: 10),
          GradientButton(t('next'), () => setState(() {
                var n = idx;
                while (n == idx && scenarios.length > 1) { n = r.nextInt(scenarios.length); }
                idx = n;
                pick = null;
              })),
        ],
      ]),
    );
  }
}

// =================== Similar-sound drills ===================
class Pair {
  final String label;
  final List<W> words;
  const Pair(this.label, this.words);
}

const pairs = <Pair>[
  Pair('ㅅ / ㅆ', [W('사다', '', 'يشتري', 'to buy', 'acheter'), W('싸다', '', 'رخيص', 'cheap', 'bon marché')]),
  Pair('ㄷ / ㅌ / ㄸ', [W('달', '', 'قمر', 'moon', 'lune'), W('탈', '', 'قناع', 'mask', 'masque'), W('딸', '', 'ابنة', 'daughter', 'fille')]),
  Pair('ㅂ / ㅍ / ㅃ', [W('불', '', 'نار', 'fire', 'feu'), W('풀', '', 'عشب', 'grass', 'herbe'), W('뿔', '', 'قرن', 'horn', 'corne')]),
  Pair('ㅈ / ㅊ / ㅉ', [W('자다', '', 'ينام', 'to sleep', 'dormir'), W('차다', '', 'بارد / يركل', 'cold / to kick', 'froid / donner un coup de pied'), W('짜다', '', 'مالح', 'salty', 'salé')]),
  Pair('ㄱ / ㅋ / ㄲ', [W('굴', '', 'محار', 'oyster', 'huître'), W('쿨', '', 'رائع (cool)', 'cool', 'cool'), W('꿀', '', 'عسل', 'honey', 'miel')]),
  Pair('ㅓ / ㅗ', [W('거리', '', 'شارع', 'street', 'rue'), W('고리', '', 'حلقة', 'ring / loop', 'anneau')]),
  Pair('ㅏ / ㅓ', [W('밤', '', 'ليل', 'night', 'nuit'), W('범', '', 'نمر', 'tiger', 'tigre')]),
];

class DrillScreen extends StatefulWidget {
  const DrillScreen({super.key});
  @override
  State<DrillScreen> createState() => _DrS();
}

class _DrS extends State<DrillScreen> {
  final r = Random();
  Pair? pair;
  late W target;
  W? pick;

  void _round() {
    target = pair!.words[r.nextInt(pair!.words.length)];
    pick = null;
    AppState.i.speak(target.ko);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('drills')), leading: pair != null ? IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => setState(() => pair = null)) : null),
        body: pair == null
            ? ListView(padding: const EdgeInsets.all(16), children: [
                Text(t('pickPair'), textAlign: TextAlign.center),
                const SizedBox(height: 10),
                for (final p in pairs)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: InkWell(
                      onTap: () => setState(() { pair = p; _round(); }),
                      child: KCard(child: Row(children: [
                        Text(p.label, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                        const Spacer(),
                        Text(p.words.map((w) => w.ko).join('  '), style: const TextStyle(color: Colors.white70)),
                      ])),
                    ),
                  ),
              ])
            : ListView(padding: const EdgeInsets.all(16), children: [
                Text(t('drillQ'), textAlign: TextAlign.center),
                const SizedBox(height: 14),
                Center(
                  child: InkWell(
                    onTap: () => AppState.i.speak(target.ko),
                    child: Container(width: 90, height: 90, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: KColors.grad), child: const Icon(Icons.volume_up, size: 44, color: Colors.white)),
                  ),
                ),
                const SizedBox(height: 16),
                for (final w in pair!.words)
                  Opt('${w.ko}   (${romanize(w.ko)})${pick == null ? '' : '\n${w.tr}'}', pick == null ? 0 : (w == target ? 1 : (w == pick ? 2 : 0)), () {
                    if (pick != null) return;
                    setState(() => pick = w);
                    AppState.i.record('drill', w == target);
                    if (w == target) AppState.i.addXp(3, lesson: true);
                  }),
                if (pick != null) GradientButton(t('next'), () => setState(_round)),
              ]),
      );
}

// =================== My plan ===================
class PlanScreen extends StatelessWidget {
  const PlanScreen({super.key});
  static const routes = {'listening': '/listening', 'reading': '/reading', 'pron': '/pronounce', 'vocab': '/vocab', 'builder': '/builder', 'etiquette': '/etiquette', 'drill': '/drill'};
  static const names = {'listening': 'listening', 'reading': 'reading', 'pron': 'pron', 'vocab': 'vocab', 'builder': 'builder', 'etiquette': 'etiquette', 'drill': 'drills'};

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('plan'))),
        body: Watch((_) {
          final s = AppState.i;
          final week = s.weekXp();
          final total = week.fold<int>(0, (a, b) => a + b);
          final mx = max(1, week.fold<int>(0, max));
          final weak = s.weakest();
          return ListView(padding: const EdgeInsets.all(16), children: [
            KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('weeklyGoal'), style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              KProgress(total / s.wgoal),
              const SizedBox(height: 4),
              Text('$total / ${s.wgoal}', style: const TextStyle(color: Colors.white60)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final g in [100, 200, 400])
                  ChoiceChip(label: Text('$g'), selected: s.wgoal == g, onSelected: (_) => s.setGoal(g)),
              ]),
            ])),
            const SizedBox(height: 10),
            KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('last7'), style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              SizedBox(
                height: 90,
                child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  for (final v in week)
                    Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 3), child: Container(height: 6 + 80 * v / mx, decoration: BoxDecoration(color: v == 0 ? Colors.white12 : KColors.primary, borderRadius: BorderRadius.circular(6))))),
                ]),
              ),
            ])),
            const SizedBox(height: 10),
            KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${t('due')}: ${Srs.dueNow()}', style: const TextStyle(fontWeight: FontWeight.w800)),
              if (weak != null) ...[
                const SizedBox(height: 6),
                Text('${t('weakest')}: ${t(names[weak] ?? weak)}', style: const TextStyle(color: KColors.orange)),
              ],
              const SizedBox(height: 10),
              GradientButton(t('practiceNow'), () => Navigator.pushNamed(context, weak != null ? (routes[weak] ?? '/vocab') : '/vocab')),
            ])),
            const SizedBox(height: 10),
            KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('skillAcc'), style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              for (final e in s.stats.entries)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    SizedBox(width: 100, child: Text(t(names[e.key] ?? e.key), style: const TextStyle(fontSize: 13))),
                    Expanded(child: KProgress(e.value[0] / max(1, e.value[0] + e.value[1]))),
                    const SizedBox(width: 8),
                    Text('${(100 * e.value[0] / max(1, e.value[0] + e.value[1])).round()}%', style: const TextStyle(fontSize: 12)),
                  ]),
                ),
            ])),
            const SizedBox(height: 10),
            Text(t('planNote'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          ]);
        }),
      );
}
