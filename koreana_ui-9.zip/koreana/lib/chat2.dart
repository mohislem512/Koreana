import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'data.dart';
import 'i18n.dart';
import 'romanize.dart';
import 'skills.dart' show lev;
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

// ---------- data model (loaded from assets/data/chat.txt) ----------
class GoodAns {
  final String pattern; // may contain * as wildcard
  final W ex;
  GoodAns(this.pattern, this.ex);
}

class BadAns {
  final W w;
  final List<String> why;
  BadAns(this.w, this.why);
}

class ChatTurn {
  final W bot;
  final good = <GoodAns>[];
  final alt = <String>[];
  final bad = <BadAns>[];
  ChatTurn(this.bot);
}

class ChatScenario {
  final String id;
  final List<String> title;
  final int minLevel;
  final turns = <ChatTurn>[];
  ChatScenario(this.id, this.title, this.minLevel);
}

final List<ChatScenario> chatScenarios = [];

Future<void> loadChatScenarios() async {
  try {
    final txt = await rootBundle.loadString('assets/data/chat.txt');
    ChatScenario? sc;
    ChatTurn? tn;
    for (final line in txt.split('\n')) {
      final p = line.trim().split('|');
      if (p.length < 2) continue;
      if (p[0] == 'S' && p.length >= 6) {
        sc = ChatScenario(p[1], [p[2], p[3], p[4]], int.tryParse(p[5]) ?? 0);
        chatScenarios.add(sc);
      } else if (p[0] == 'T' && sc != null && p.length >= 5) {
        tn = ChatTurn(W(p[1], romanize(p[1]), p[2], p[3], p[4]));
        sc.turns.add(tn);
      } else if (p[0] == 'G' && tn != null && p.length >= 6) {
        tn.good.add(GoodAns(p[1], W(p[2], romanize(p[2]), p[3], p[4], p[5])));
      } else if (p[0] == 'A' && tn != null) {
        tn.alt.add(p[1]);
      } else if (p[0] == 'B' && tn != null && p.length >= 8) {
        tn.bad.add(BadAns(W(p[1], romanize(p[1]), p[2], p[3], p[4]), [p[5], p[6], p[7]]));
      }
    }
  } catch (_) {}
}

// ---------- answer checking ----------
String _norm(String s) => s.toLowerCase().replaceAll(RegExp(r'[\s.,!?~。…·"“”]'), '');
bool _hasHangul(String s) => s.runes.any((r) => (r >= 0xAC00 && r <= 0xD7A3) || (r >= 0x3131 && r <= 0x318E));

bool _match(String pattern, String input) {
  final n = _norm(pattern), i = _norm(input);
  if (!n.contains('*')) return n == i;
  final re = RegExp('^${n.split('*').map(RegExp.escape).join('(.+)')}\$');
  return re.hasMatch(i);
}

class _Verdict {
  final int kind; // 0 correct, 1 close, 2 wrong, 3 not Korean, 4 empty
  final String? why, model;
  _Verdict(this.kind, {this.why, this.model});
}

_Verdict _judge(ChatTurn turn, String input) {
  final inp = _norm(input);
  if (inp.isEmpty) return _Verdict(4);
  if (!_hasHangul(input)) return _Verdict(3);
  for (final b in turn.bad) {
    if (_norm(b.w.ko) == inp) return _Verdict(2, why: b.why[gLang]);
  }
  for (final g in turn.good) {
    if (_match(g.pattern, input)) return _Verdict(0);
  }
  for (final a in turn.alt) {
    if (_match(a, input)) return _Verdict(0);
  }
  String? best;
  var bs = 0.0;
  for (final c in [for (final g in turn.good) g.ex.ko, ...turn.alt.where((a) => !a.contains('*'))]) {
    final n = _norm(c);
    if (n.length < 4) continue;
    final sim = 1 - lev(inp, n) / max(inp.length, n.length);
    if (sim > bs) {
      bs = sim;
      best = c;
    }
  }
  if (best != null && bs >= .8) return _Verdict(1, model: best);
  return _Verdict(2);
}

// ---------- scenario list ----------
class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('chat'))),
        body: Watch((_) => ListView(padding: const EdgeInsets.all(16), children: [
              Text(t('chooseScenario'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 12),
              for (final s in chatScenarios)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    onTap: s.minLevel > AppState.i.level
                        ? null
                        : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatSession(s))),
                    child: Opacity(
                      opacity: s.minLevel > AppState.i.level ? .5 : 1,
                      child: KCard(
                        child: Row(children: [
                          const CircleAvatar(backgroundColor: KColors.primary, child: Icon(Icons.forum, color: Colors.white)),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(s.title[gLang], style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                            Text(t('lv${s.minLevel}'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
                          ])),
                          Icon(AppState.i.chatDone.contains(s.id) ? Icons.check_circle : (s.minLevel > AppState.i.level ? Icons.lock : Icons.chevron_left),
                              color: AppState.i.chatDone.contains(s.id) ? KColors.green : Colors.white38),
                        ]),
                      ),
                    ),
                  ),
                ),
            ])),
      );
}

// ---------- the conversation ----------
class _Msg {
  final int kind; // 0 bot, 1 user, 2 feedback good, 3 feedback bad
  final String text;
  final W? w;
  _Msg(this.kind, this.text, [this.w]);
}

class _Chip {
  final W w;
  final GoodAns? good;
  final BadAns? bad;
  _Chip(this.w, {this.good, this.bad});
}

class ChatSession extends StatefulWidget {
  final ChatScenario sc;
  const ChatSession(this.sc, {super.key});
  @override
  State<ChatSession> createState() => _CsS();
}

class _CsS extends State<ChatSession> {
  final r = Random();
  final msgs = <_Msg>[];
  final ctl = TextEditingController(), sc = ScrollController();
  var chips = <_Chip>[];
  int turn = 0, attempts = 0;
  bool done = false, busy = false;

  ChatTurn get cur => widget.sc.turns[turn];

  @override
  void initState() {
    super.initState();
    _begin();
  }

  void _begin() {
    msgs.clear();
    turn = 0;
    attempts = 0;
    done = false;
    busy = false;
    _ask();
  }

  void _ask() {
    msgs.add(_Msg(0, '', cur.bot));
    attempts = 0;
    final g = cur.good[r.nextInt(cur.good.length)];
    final bs = [...cur.bad]..shuffle(r);
    chips = [_Chip(g.ex, good: g), for (final b in bs.take(2)) _Chip(b.w, bad: b)]..shuffle(r);
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.i.speak(cur.bot.ko));
    _scroll();
  }

  void _scroll() => Future.delayed(const Duration(milliseconds: 200), () {
        if (sc.hasClients) sc.animateTo(sc.position.maxScrollExtent + 300, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  void _advance() {
    busy = true;
    Future.delayed(const Duration(milliseconds: 1100), () {
      if (!mounted) return;
      setState(() {
        busy = false;
        if (turn + 1 < widget.sc.turns.length) {
          turn++;
          _ask();
        } else {
          done = true;
          chips = [];
          msgs.add(_Msg(2, '🎉 ${t('scenDone')}'));
          AppState.i.markChat(widget.sc.id);
          AppState.i.addXp(15, lesson: true);
        }
      });
      _scroll();
    });
  }

  void _good({String? model}) {
    msgs.add(_Msg(2, model == null ? '✅ ${t('fbOk')}' : '👍 ${t('fbClose')} $model'));
    AppState.i.record('chat', true);
    AppState.i.addXp(5);
    setState(() => chips = []);
    _advance();
  }

  void _bad(String? why, {_Chip? chip}) {
    attempts++;
    AppState.i.record('chat', false);
    final g = cur.good.first.ex;
    final head = '❌ ${t('fbWrong')}${why != null ? '\n$why' : ''}';
    if (attempts >= 2) {
      msgs.add(_Msg(3, '$head\n${t('fbReveal')} ${g.ko}\n${g.tr}'));
      setState(() => chips = []);
      _advance();
    } else {
      msgs.add(_Msg(3, '$head\n${t('fbRetry')}'));
      setState(() { if (chip != null) chips.remove(chip); });
    }
  }

  void _pick(_Chip c) {
    if (busy || done) return;
    setState(() => msgs.add(_Msg(1, c.w.ko, c.w)));
    if (c.good != null) {
      _good();
    } else {
      _bad(c.bad!.why[gLang], chip: c);
    }
    _scroll();
  }

  void _send() {
    final txt = ctl.text.trim();
    if (txt.isEmpty || busy || done) return;
    ctl.clear();
    final v = _judge(cur, txt);
    setState(() => msgs.add(_Msg(1, txt)));
    if (v.kind == 3) {
      setState(() => msgs.add(_Msg(3, '⌨️ ${t('fbNotKo')}')));
    } else if (v.kind == 0 || v.kind == 1) {
      _good(model: v.kind == 1 ? v.model : null);
    } else {
      _bad(v.why ?? t('fbGeneric'));
    }
    _scroll();
  }

  Widget _bubble(_Msg m) {
    if (m.kind >= 2) {
      return Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: (m.kind == 2 ? KColors.green : Colors.redAccent).withOpacity(.22), borderRadius: BorderRadius.circular(14), border: Border.all(color: m.kind == 2 ? KColors.green : Colors.redAccent)),
        child: Text(m.text, style: const TextStyle(height: 1.5)),
      );
    }
    final bot = m.kind == 0;
    return Align(
      alignment: bot ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        constraints: const BoxConstraints(maxWidth: 310),
        decoration: BoxDecoration(color: bot ? const Color(0xFFF1F2FA) : const Color(0xFFDCE8FB), borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisSize: MainAxisSize.min, children: [
            Flexible(child: Text(m.w?.ko ?? m.text, style: const TextStyle(color: Colors.black87, fontSize: 16, fontWeight: FontWeight.w700))),
            InkWell(onTap: () => AppState.i.speak(m.w?.ko ?? m.text), child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.volume_up, size: 18, color: KColors.primary))),
          ]),
          if (m.w != null) Text(m.w!.rom, style: const TextStyle(color: Colors.black45, fontSize: 11)),
          if (m.w != null) Text(m.w!.tr, style: const TextStyle(color: Colors.black87, fontSize: 13)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.sc.title[gLang])),
        body: Column(children: [
          Expanded(child: ListView(controller: sc, padding: const EdgeInsets.all(16), children: [for (final m in msgs) _bubble(m)])),
          if (!done && chips.isNotEmpty)
            SizedBox(
              height: 78,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
                for (final c in chips)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8),
                    child: ActionChip(
                      label: Text('${c.w.ko}\n${c.w.tr}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                      onPressed: busy ? null : () => _pick(c),
                    ),
                  ),
              ]),
            ),
          if (done)
            Padding(padding: const EdgeInsets.all(12), child: GradientButton(t('restart'), () => setState(_begin)))
          else
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
              child: Row(children: [
                Expanded(child: TextField(controller: ctl, onSubmitted: (_) => _send(), decoration: InputDecoration(hintText: t('typeMsg'), filled: true, fillColor: KColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(24))))),
                IconButton(onPressed: busy ? null : _send, icon: const Icon(Icons.send, color: KColors.primary)),
              ]),
            ),
        ]),
      );
}
