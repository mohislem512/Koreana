import 'package:flutter/services.dart' show rootBundle;
import 'chat2.dart';
import 'data.dart';
import 'romanize.dart';

/// Loads assets/data/lv0..lv4.txt  (type|korean|arabic|english|french)
/// type: w = word, s = sentence. Romanization is generated automatically.
class Content {
  static Future<void> load() async {
    await loadChatScenarios();
    for (var lv = 0; lv < 5; lv++) {
      reading[lv] = [for (final w in reading[lv]) w.rom.isEmpty ? W(w.ko, romanize(w.ko), w.ar, w.en, w.fr) : w];
      try {
        final txt = await rootBundle.loadString('assets/data/lv$lv.txt');
        final seen = <String>{...vocab[lv].map((w) => w.ko), ...reading[lv].map((w) => w.ko)};
        for (final line in txt.split('\n')) {
          final p = line.trim().split('|');
          if (p.length < 5 || seen.contains(p[1])) continue;
          seen.add(p[1]);
          final w = W(p[1], romanize(p[1]), p[2], p[3], p[4]);
          if (p[0] == 's') {
            reading[lv].add(w);
          } else {
            vocab[lv].add(w);
          }
        }
      } catch (_) {}
    }
  }
}
