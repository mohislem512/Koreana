import 'package:flutter/material.dart';
import 'auth.dart';
import 'data.dart';
import 'i18n.dart';
import 'tabs.dart';
import 'premium.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

Widget langChips() => StatefulBuilder(
      builder: (c, set) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (final e in [[0, 'العربية'], [1, 'English'], [2, 'Français']])
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: Text('${e[1]}'),
              selected: gLang == e[0],
              onSelected: (_) => AppState.i.setLang(e[0] as int),
            ),
          ),
      ]),
    );

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              langChips(),
              const Spacer(),
              const Logo(130),
              const SizedBox(height: 14),
              const Text('Koreana', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w800, color: Colors.white)),
              const SizedBox(height: 6),
              Text(t('tag'), style: const TextStyle(color: Colors.white70, fontSize: 16)),
              const Spacer(),
              GradientButton(t('start'), () => Navigator.pushNamed(context, '/auth', arguments: true)),
              const SizedBox(height: 10),
              OutlinedButton(
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                onPressed: () => Navigator.pushNamed(context, '/auth', arguments: false),
                child: Text(t('login')),
              ),
            ]),
          ),
        ),
      );
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthState();
}

class _AuthState extends State<AuthScreen> {
  final name = TextEditingController(), email = TextEditingController(), pass = TextEditingController();
  String err = '', info = '';
  bool busy = false;

  Future<void> _go(bool reg) async {
    final n = name.text.trim(), e = email.text.trim(), p = pass.text;
    if (e.isEmpty || p.isEmpty || (reg && n.isEmpty)) return setState(() => err = t('fill'));
    if (reg && p.length < 8) return setState(() => err = t('weak'));
    setState(() { busy = true; err = ''; });
    try {
      if (reg) { await Auth.signUp(n, e, p); } else { await Auth.signIn(e, p); }
      await AppState.i.loadUser();
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, AppState.i.onb ? '/home' : '/levels', (_) => false);
    } on AuthError catch (x) {
      setState(() => err = x.msg);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final reg = (ModalRoute.of(context)?.settings.arguments as bool?) ?? false;
    Widget f(TextEditingController c, String l, {bool pw = false, TextInputType? k}) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: TextField(controller: c, obscureText: pw, keyboardType: k, autocorrect: false, decoration: InputDecoration(labelText: l, filled: true, fillColor: KColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
        );
    return Scaffold(
      appBar: AppBar(title: Text(t(reg ? 'start' : 'login'))),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        const Center(child: Logo(90)),
        const SizedBox(height: 20),
        if (reg) f(name, t('name')),
        f(email, t('email'), k: TextInputType.emailAddress),
        f(pass, t('pass'), pw: true),
        if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(err, style: const TextStyle(color: Colors.redAccent))),
        if (info.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(info, style: const TextStyle(color: KColors.green))),
        GradientButton(busy ? '...' : t(reg ? 'start' : 'login'), busy ? null : () => _go(reg)),
        if (!reg && Auth.cloud)
          TextButton(
            onPressed: () async {
              try { await Auth.reset(email.text.trim()); setState(() => info = t('sent')); } on AuthError catch (x) { setState(() => err = x.msg); }
            },
            child: Text(t('forgot')),
          ),
        if (!Auth.cloud) Padding(padding: const EdgeInsets.only(top: 14), child: Text(t('local'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12))),
      ]),
    );
  }
}

class LevelScreen extends StatelessWidget {
  const LevelScreen({super.key});
  static const cols = [KColors.green, KColors.gold, Color(0xFFB04FD8), KColors.blue, KColors.orange];
  static const icons = [Icons.eco, Icons.emoji_events, Icons.explore, Icons.rocket_launch, Icons.star];
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('chooseLevel'))),
        body: Watch((_) => ListView(padding: const EdgeInsets.all(16), children: [
              for (var i = 0; i < 5; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      if (AppState.i.locked(i)) {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const PaywallScreen()));
                      } else {
                        AppState.i.setLevel(i);
                        Navigator.pushNamedAndRemoveUntil(context, '/home', (_) => false);
                      }
                    },
                    child: KCard(
                      child: Row(children: [
                        CircleAvatar(radius: 26, backgroundColor: cols[i], child: Icon(icons[i], color: Colors.white)),
                        const SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(t('lv$i'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                          Text(t('ld$i'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
                        ])),
                        Icon(AppState.i.locked(i) ? Icons.lock : Icons.chevron_left, color: AppState.i.locked(i) ? KColors.gold : Colors.white38),
                      ]),
                    ),
                  ),
                ),
            ])),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  int i = 0;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.resumed) {
      if (AppState.i.syncPending) AppState.i.save(); // retry cloud sync only if it was pending
      AppState.i.refreshPremium();
    }
  }

  @override
  Widget build(BuildContext context) {
    const pages = [HomeTab(), LearnTab(), VocabTab(), TrainTab(), ProfileTab()];
    return Scaffold(
      body: SafeArea(child: pages[i]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v) => setState(() => i = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: t('home')),
          NavigationDestination(icon: const Icon(Icons.menu_book_outlined), selectedIcon: const Icon(Icons.menu_book), label: t('learn')),
          NavigationDestination(icon: const Icon(Icons.style_outlined), selectedIcon: const Icon(Icons.style), label: t('vocab')),
          NavigationDestination(icon: const Icon(Icons.fitness_center_outlined), selectedIcon: const Icon(Icons.fitness_center), label: t('train')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: t('profile')),
        ],
      ),
    );
  }
}
