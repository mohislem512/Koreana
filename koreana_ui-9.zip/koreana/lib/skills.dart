import 'dart:math';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'data.dart';
import 'i18n.dart';
import 'srs.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

List<W> poolMixed() => [...vocab[AppState.i.level], ...reading[AppState.i.level]];

// ---------------- Listening ----------------
class ListeningScreen extends StatefulWidget {
  final List<W>? pool;
  const ListeningScreen({super.key, this.pool});
  @override
  State<ListeningScreen> createState() => _LiS();
}

class _LiS extends State<ListeningScreen> {
  late W cur;
  late List<W> opts;
  W? pick;
  int ok = 0, n = 0;
  @override
  void initState() {
    super.initState();
    _new();
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.i.speak(cur.ko));
  }

  void _new() {
    final all = widget.pool ?? poolMixed();
    cur = Srs.next(all);
    final long = cur.ko.length > 8;
    final same = all.where((w) => (w.ko.length > 8) == long && w != cur).toList()..shuffle();
    opts = [cur, ...same.take(3)]..shuffle();
    pick = null;
  }

  void _tap(W w) {
    if (pick != null) return;
    setState(() { pick = w; n++; if (w == cur) ok++; });
    Srs.grade(cur, w == cur);
    AppState.i.record('listening', w == cur);
    if (w == cur) AppState.i.addXp(5, lesson: true);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('listening'))),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Text(t('listenQ'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 20),
          Center(
            child: InkWell(
              onTap: () => AppState.i.speak(cur.ko),
              child: Container(width: 100, height: 100, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: KColors.grad), child: const Icon(Icons.volume_up, size: 48, color: Colors.white)),
            ),
          ),
          const SizedBox(height: 8),
          Center(child: Text('$ok / $n', style: const TextStyle(color: Colors.white60))),
          const SizedBox(height: 16),
          for (final w in opts) Opt(w.tr, pick == null ? 0 : (w == cur ? 1 : (w == pick ? 2 : 0)), () => _tap(w)),
          if (pick != null) ...[
            Center(child: Text(pick == cur ? t('good') : t('bad'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
            const SizedBox(height: 6),
            Center(child: Text('${cur.ko}\n${cur.rom}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))),
            const SizedBox(height: 12),
            GradientButton(t('next'), () { setState(_new); AppState.i.speak(cur.ko); }),
          ],
        ]),
      );
}

// ---------------- Pronunciation ----------------
String normKo(String s) => s.replaceAll(RegExp(r'[\s?.!,]'), '');

/// Marks which characters of [a] (target) also appear, in order, in [b] (what the recognizer heard).
List<bool> lcsMask(String a, String b) {
  final n = a.length, m = b.length;
  final d = List.generate(n + 1, (_) => List<int>.filled(m + 1, 0));
  for (var i = n - 1; i >= 0; i--) {
    for (var j = m - 1; j >= 0; j--) {
      d[i][j] = a[i] == b[j] ? d[i + 1][j + 1] + 1 : max(d[i + 1][j], d[i][j + 1]);
    }
  }
  final mask = List<bool>.filled(n, false);
  var i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] == b[j]) {
      mask[i] = true;
      i++;
      j++;
    } else if (d[i + 1][j] >= d[i][j + 1]) {
      i++;
    } else {
      j++;
    }
  }
  return mask;
}

int lev(String a, String b) {
  final m = List.generate(a.length + 1, (i) => List<int>.filled(b.length + 1, 0));
  for (var i = 0; i <= a.length; i++) { m[i][0] = i; }
  for (var j = 0; j <= b.length; j++) { m[0][j] = j; }
  for (var i = 1; i <= a.length; i++) {
    for (var j = 1; j <= b.length; j++) {
      m[i][j] = min(min(m[i - 1][j] + 1, m[i][j - 1] + 1), m[i - 1][j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
    }
  }
  return m[a.length][b.length];
}

class PronounceScreen extends StatefulWidget {
  const PronounceScreen({super.key});
  @override
  State<PronounceScreen> createState() => _PrS();
}

class _PrS extends State<PronounceScreen> {
  final stt = SpeechToText();
  bool ready = false, listening = false;
  late W w;
  String heard = '', msg = '';
  int? score;

  @override
  void initState() {
    super.initState();
    w = Srs.next(poolMixed());
  }

  Future<void> _listen() async {
    if (!ready) {
      ready = await stt.initialize(
        onStatus: (s) {
          if ((s == 'done' || s == 'notListening') && mounted) {
            setState(() => listening = false);
            if (score == null && heard.isNotEmpty) _score();
          }
        },
        onError: (_) { if (mounted) setState(() => listening = false); },
      );
    }
    if (!ready) return setState(() => msg = t('micErr'));
    setState(() { listening = true; heard = ''; score = null; msg = ''; });
    await stt.listen(localeId: 'ko_KR', onResult: (r) {
      setState(() => heard = r.recognizedWords);
      if (r.finalResult) _score();
    });
  }

  void _score() {
    if (score != null || !mounted) return;
    String norm(String s) => s.replaceAll(RegExp(r'[\s?.!,]'), '');
    final a = norm(heard), b = norm(w.ko);
    final sim = 1 - lev(a, b) / max(1, max(a.length, b.length));
    setState(() => score = (sim * 100).round());
    Srs.grade(w, score! >= 70);
    AppState.i.record('pron', score! >= 70);
    if (score! >= 70) AppState.i.addXp(10, lesson: true);
  }

  @override
  void dispose() {
    stt.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('pron'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          KCard(
            padding: const EdgeInsets.all(26),
            child: Column(children: [
              Text(w.ko, textAlign: TextAlign.center, style: TextStyle(fontSize: w.ko.length > 8 ? 26 : 46, fontWeight: FontWeight.w800)),
              Text('(${w.rom})', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
              Text(w.tr, textAlign: TextAlign.center, style: const TextStyle(color: KColors.primary, fontWeight: FontWeight.w700)),
              const SizedBox(height: 18),
              OutlinedButton.icon(onPressed: () => AppState.i.speak(w.ko), icon: const Icon(Icons.play_arrow), label: Text(t('play'))),
              const SizedBox(height: 18),
              InkWell(
                onTap: listening ? null : _listen,
                child: Container(
                  width: 88, height: 88,
                  decoration: BoxDecoration(shape: BoxShape.circle, gradient: KColors.grad, boxShadow: listening ? [BoxShadow(color: KColors.primary.withOpacity(.7), blurRadius: 24, spreadRadius: 6)] : null),
                  child: Icon(listening ? Icons.hearing : Icons.mic, color: Colors.white, size: 42),
                ),
              ),
              const SizedBox(height: 8),
              Text(t('tapSpeak'), style: const TextStyle(color: KColors.blue)),
              if (heard.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text('${t('heard')} $heard', style: const TextStyle(fontSize: 16))),
              if (score != null) Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('${t('accuracy')}: $score%  ${score! >= 70 ? '✅' : '🔁'}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: score! >= 70 ? KColors.green : KColors.orange)),
              ),
              if (score != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Wrap(alignment: WrapAlignment.center, children: [
                    for (final e in lcsMask(normKo(w.ko), normKo(heard)).asMap().entries)
                      Text(normKo(w.ko)[e.key], style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: e.value ? KColors.green : KColors.orange)),
                  ]),
                ),
              if (msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
            ]),
          ),
          const SizedBox(height: 14),
          GradientButton(t('next'), () => setState(() { w = Srs.next(poolMixed()); heard = ''; score = null; msg = ''; })),
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: () => Navigator.pushNamed(context, '/drill'), icon: const Icon(Icons.compare_arrows), label: Text(t('drills'))),
          const SizedBox(height: 10),
          Text(t('pronNote'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
      );
}

// ---------------- Reading ----------------
class ReadingScreen extends StatefulWidget {
  final List<W>? pool;
  const ReadingScreen({super.key, this.pool});
  @override
  State<ReadingScreen> createState() => _ReS();
}

class _ReS extends State<ReadingScreen> {
  bool show = false;
  String? pick;
  late W cur;
  late List<String> opts;
  final r = Random();
  @override
  void initState() {
    super.initState();
    _new();
  }

  void _new() {
    cur = Srs.next(widget.pool ?? reading[AppState.i.level]);
    final all = [for (final l in reading) ...l];
    final s = <String>{cur.tr};
    var guard = 0;
    while (s.length < 3 && guard++ < 60) { s.add(all[r.nextInt(all.length)].tr); }
    opts = s.toList()..shuffle();
    pick = null;
    show = false;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('reading'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          KCard(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              Text(cur.ko, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, height: 1.5)),
              Text(cur.rom, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
              const SizedBox(height: 6),
              IconButton(iconSize: 36, color: KColors.primary, onPressed: () => AppState.i.speak(cur.ko), icon: const Icon(Icons.volume_up)),
              TextButton(onPressed: () => setState(() => show = !show), child: Text(t('showTr'))),
              if (show) Text(cur.tr, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 16),
          Text(t('meaning'), style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (final o in opts)
            Opt(o, pick == null ? 0 : (o == cur.tr ? 1 : (o == pick ? 2 : 0)), () {
              if (pick != null) return;
              setState(() => pick = o);
              Srs.grade(cur, o == cur.tr);
              AppState.i.record('reading', o == cur.tr);
              if (o == cur.tr) AppState.i.addXp(8, lesson: true);
            }),
          if (pick != null) GradientButton(t('next'), () => setState(_new)),
        ]),
      );
}

// ---------------- Vocabulary flashcards (spaced repetition) ----------------
class VocabScreen extends StatefulWidget {
  final List<W>? pool;
  const VocabScreen({super.key, this.pool});
  @override
  State<VocabScreen> createState() => _VoS();
}

class _VoS extends State<VocabScreen> {
  late W w;
  bool flip = false;
  List<W> get pool => widget.pool ?? vocab[AppState.i.level];
  @override
  void initState() {
    super.initState();
    w = Srs.next(pool);
  }

  void _next() => setState(() { w = Srs.next(pool); flip = false; });

  @override
  Widget build(BuildContext context) {
    final nk = Srs.learned(pool);
    return Scaffold(
      appBar: AppBar(title: Text(t('vocab'))),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          KProgress(nk / pool.length),
          const SizedBox(height: 6),
          Text('$nk / ${pool.length} ${t('learned')}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
          const SizedBox(height: 14),
          Expanded(
            child: InkWell(
              onTap: () { setState(() => flip = !flip); AppState.i.speak(w.ko); },
              child: KCard(
                padding: const EdgeInsets.all(28),
                child: SizedBox(
                  width: double.infinity,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(w.ko, textAlign: TextAlign.center, style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800)),
                    Text('(${w.rom})', style: const TextStyle(color: Colors.white60)),
                    const SizedBox(height: 18),
                    Text(flip ? w.tr : t('flip'), textAlign: TextAlign.center, style: TextStyle(fontSize: flip ? 24 : 13, color: flip ? KColors.primary : Colors.white38, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 14),
                    const Icon(Icons.volume_up, color: KColors.primary),
                  ]),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            for (final e in [[0, 'rateAgain', Colors.redAccent], [1, 'rateHard', KColors.orange], [2, 'rateGood', KColors.green], [3, 'rateEasy', KColors.blue]])
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: e[2] as Color, padding: const EdgeInsets.symmetric(vertical: 14)),
                    onPressed: () {
                      final r = e[0] as int;
                      if (r >= 2 && Srs.box(w) < 3) AppState.i.addXp(3, lesson: true);
                      Srs.rate(w, r);
                      AppState.i.record('vocab', r >= 2);
                      _next();
                    },
                    child: Text(t(e[1] as String), style: const TextStyle(fontSize: 12)),
                  ),
                ),
              ),
          ]),
        ]),
      ),
    );
  }
}

