import 'dart:math';
import 'package:flutter/material.dart';
import 'auth.dart';
import 'batch_a.dart';
import 'data.dart';
import 'i18n.dart';
import 'lessons.dart';
import 'premium.dart';
import 'screens.dart' show langChips;
import 'skills.dart';
import 'srs.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

const levelShort = ['A0', 'A1', 'A2–B1', 'B2–C1', 'C2'];

List<List<W>> chunks(List<W> l, [int n = 10]) => [for (var i = 0; i < l.length; i += n) l.sublist(i, min(i + n, l.length))];
int learnedIn(List<W> l) => l.where((w) => Srs.box(w) >= 3).length;
void goPaywall(BuildContext c) => Navigator.push(c, MaterialPageRoute(builder: (_) => const PaywallScreen()));
void openRoute(BuildContext c, String route) {
  if (AppState.i.locked(AppState.i.level)) {
    goPaywall(c);
  } else {
    Navigator.pushNamed(c, route);
  }
}

void openPage(BuildContext c, Widget page) {
  if (AppState.i.locked(AppState.i.level)) {
    goPaywall(c);
  } else {
    Navigator.push(c, MaterialPageRoute(builder: (_) => page));
  }
}

double levelCompletion(int lv) {
  final lsn = lessons[lv].length + moreLessons[lv].length;
  final seen = [for (var i = 0; i < lsn; i++) if (AppState.i.lessonsSeen.contains('$lv:$i')) i].length;
  final total = vocab[lv].length + reading[lv].length + lsn;
  return (learnedIn(vocab[lv]) + learnedIn(reading[lv]) + seen) / max(1, total);
}

class _Act {
  final String title, sub;
  final VoidCallback go;
  _Act(this.title, this.sub, this.go);
}

_Act _nextAction(BuildContext ctx) {
  final lv = AppState.i.level;
  if (AppState.i.locked(lv)) return _Act(t('lockedLevel'), t('perks'), () => goPaywall(ctx));
  final due = Srs.dueNow();
  if (due > 0) return _Act('${t('due')}: $due', t('reviewSub'), () => Navigator.pushNamed(ctx, '/vocab'));
  final sets = chunks(vocab[lv]);
  for (var i = 0; i < sets.length; i++) {
    if (learnedIn(sets[i]) < sets[i].length) {
      final pool = sets[i];
      return _Act(t('newWords'), '${t('set')} ${i + 1}', () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => VocabScreen(pool: pool))));
    }
  }
  final lsn = [...lessons[lv], ...moreLessons[lv]];
  for (var i = 0; i < lsn.length; i++) {
    if (!AppState.i.lessonsSeen.contains('$lv:$i')) {
      final idx = i;
      return _Act(lsn[i].title[gLang], t('grammar'), () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => GrammarScreen(lv, idx))));
    }
  }
  return _Act(t('reading'), t('practiceNow'), () => Navigator.pushNamed(ctx, '/reading'));
}

Widget _statTile(IconData ic, Color c, String v, String l) => Expanded(
      child: KCard(padding: const EdgeInsets.all(10), child: Column(children: [
        Icon(ic, color: c),
        Text(v, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        Text(l, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: Colors.white60)),
      ])),
    );

Widget _weekBars(List<int> week) {
  final mx = max(1, week.fold<int>(0, max));
  return SizedBox(
    height: 70,
    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      for (final v in week)
        Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 3), child: Container(height: 6 + 60 * v / mx, decoration: BoxDecoration(color: v == 0 ? Colors.white12 : KColors.primary, borderRadius: BorderRadius.circular(6))))),
    ]),
  );
}

// =================== HOME ===================
class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  @override
  Widget build(BuildContext context) => Watch((c) {
        final s = AppState.i, lv = s.level;
        final name = Auth.user?.name ?? '';
        final words = vocab[lv];
        final wod = words[DateTime.now().difference(DateTime(DateTime.now().year)).inDays % words.length];
        final act = _nextAction(context);
        final week = s.weekXp();
        return ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            CircleAvatar(backgroundColor: KColors.primary, child: Text(name.isEmpty ? '?' : name[0].toUpperCase(), style: const TextStyle(color: Colors.white))),
            const SizedBox(width: 10),
            Expanded(child: Text('${t('hello')} $name', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
            if (s.premium) Chip(avatar: const Icon(Icons.verified, color: KColors.gold, size: 18), label: Text(t('verified'), style: const TextStyle(fontSize: 11))),
          ]),
          const SizedBox(height: 12),
          KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (s.syncPending) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('⚠️ ${t('offlineBanner')}', style: const TextStyle(color: KColors.orange, fontSize: 12))),
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t('yourLevel'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
                Text(t('lv$lv'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                Text('📍 ${places[lv][gLang]}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
              Column(children: [
                Text('${(levelCompletion(lv) * 100).round()}%', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: KColors.green)),
                Text(t('completion'), style: const TextStyle(fontSize: 10, color: Colors.white60)),
              ]),
            ]),
            const SizedBox(height: 8),
            KProgress(s.lxp / 100),
          ])),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(gradient: KColors.grad, borderRadius: BorderRadius.circular(22)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [const Icon(Icons.auto_stories, color: Colors.white), const SizedBox(width: 8), Expanded(child: Text(act.title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)))]),
              const SizedBox(height: 4),
              Text(act.sub, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 12),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: KColors.bg),
                onPressed: act.go,
                child: Text(t('continue'), style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: () => AppState.i.speak(wod.ko),
            child: KCard(child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('✨ ${t('wordOfDay')}', style: const TextStyle(color: KColors.gold, fontSize: 12, fontWeight: FontWeight.w700)),
                Text(wod.ko, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
                Text(wod.rom, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                Text(wod.tr, style: const TextStyle(color: KColors.primary, fontWeight: FontWeight.w700)),
              ])),
              const Icon(Icons.volume_up, color: KColors.primary, size: 30),
            ])),
          ),
          const SizedBox(height: 12),
          Row(children: [
            _statTile(Icons.check_circle, KColors.gold, '${s.done}', t('done')),
            const SizedBox(width: 8),
            _statTile(Icons.local_fire_department, KColors.orange, '${s.streak}', t('streak')),
            const SizedBox(width: 8),
            _statTile(Icons.star, KColors.gold, '${s.xp}', t('points')),
          ]),
          const SizedBox(height: 12),
          InkWell(
            onTap: () => Navigator.pushNamed(context, '/plan'),
            child: KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.flag, color: KColors.gold),
                const SizedBox(width: 8),
                Expanded(child: Text(t('plan'), style: const TextStyle(fontWeight: FontWeight.w800))),
                Text('${week.fold<int>(0, (a, b) => a + b)} / ${s.wgoal}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
              ]),
              const SizedBox(height: 10),
              _weekBars(week),
            ])),
          ),
        ]);
      });
}

// =================== LEARN (curriculum) ===================
class LearnTab extends StatefulWidget {
  const LearnTab({super.key});
  @override
  State<LearnTab> createState() => _LeS();
}

class _LeS extends State<LearnTab> {
  int? view;

  Widget _unit(IconData ic, Color col, String title, String sub, double prog, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          onTap: onTap,
          child: KCard(child: Row(children: [
            Container(width: 44, height: 44, decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(14)), child: Icon(ic, color: Colors.white)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              KProgress(prog),
            ])),
            const SizedBox(width: 10),
            Text(sub, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ])),
        ),
      );

  @override
  Widget build(BuildContext context) => Watch((_) {
        final lv = view ?? AppState.i.level;
        final locked = AppState.i.locked(lv);
        final vs = chunks(vocab[lv]), ss = chunks(reading[lv]);
        final lsn = [...lessons[lv], ...moreLessons[lv]];
        return ListView(padding: const EdgeInsets.all(16), children: [
          SizedBox(
            height: 44,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (var i = 0; i < 5; i++)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: ChoiceChip(
                    avatar: AppState.i.locked(i) ? const Icon(Icons.lock, size: 14) : null,
                    label: Text(levelShort[i]),
                    selected: lv == i,
                    onSelected: (_) => setState(() => view = i),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 10),
          Text(t('lv$lv'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          KProgress(levelCompletion(lv)),
          const SizedBox(height: 14),
          if (locked) ...[
            KCard(child: Column(children: [
              const Icon(Icons.lock, color: KColors.gold, size: 40),
              const SizedBox(height: 8),
              Text(t('lockedLevel'), style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(t('perks'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 10),
              GradientButton(t('premium'), () => goPaywall(context)),
            ])),
          ] else ...[
            Text(t('unitsGrammar'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            for (var i = 0; i < lsn.length; i++)
              _unit(Icons.rule, KColors.primary, lsn[i].title[gLang], AppState.i.lessonsSeen.contains('$lv:$i') ? '✓' : '', AppState.i.lessonsSeen.contains('$lv:$i') ? 1.0 : 0.0,
                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => GrammarScreen(lv, i)))),
            const SizedBox(height: 8),
            Text(t('unitsVocab'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            for (var i = 0; i < vs.length; i++)
              _unit(Icons.style, KColors.green, '${t('set')} ${i + 1}  ·  ${vs[i].first.ko}', '${learnedIn(vs[i])}/${vs[i].length}', learnedIn(vs[i]) / vs[i].length,
                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => VocabScreen(pool: vs[i])))),
            const SizedBox(height: 8),
            Text(t('unitsSent'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            for (var i = 0; i < ss.length; i++)
              _unit(Icons.menu_book, KColors.orange, '${t('set')} ${i + 1}  ·  ${ss[i].first.ko}', '${learnedIn(ss[i])}/${ss[i].length}', learnedIn(ss[i]) / ss[i].length,
                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReadingScreen(pool: ss[i])))),
          ],
        ]);
      });
}

class GrammarScreen extends StatefulWidget {
  final int level, index;
  const GrammarScreen(this.level, this.index, {super.key});
  @override
  State<GrammarScreen> createState() => _GrS();
}

class _GrS extends State<GrammarScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.i.markLesson('${widget.level}:${widget.index}'));
  }

  @override
  Widget build(BuildContext context) {
    final l = [...lessons[widget.level], ...moreLessons[widget.level]][widget.index];
    return Scaffold(
      appBar: AppBar(title: Text(l.title[gLang], style: const TextStyle(fontSize: 16))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        KCard(padding: const EdgeInsets.all(18), child: Text(l.body[gLang], style: const TextStyle(height: 1.8, fontSize: 15))),
        const SizedBox(height: 12),
        for (final w in l.ex)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: InkWell(
              onTap: () => AppState.i.speak(w.ko),
              child: KCard(child: Row(children: [
                const Icon(Icons.volume_up, color: KColors.primary),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(w.ko, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  if (w.rom.isNotEmpty) Text(w.rom, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  Text(w.tr, style: const TextStyle(color: KColors.primary)),
                ])),
              ])),
            ),
          ),
        const SizedBox(height: 8),
        GradientButton(t('next'), () => Navigator.pop(context)),
      ]),
    );
  }
}

// =================== VOCABULARY (dictionary) ===================
class VocabTab extends StatefulWidget {
  const VocabTab({super.key});
  @override
  State<VocabTab> createState() => _VtS();
}

class _VtS extends State<VocabTab> {
  String q = '';
  int kind = 0; // 0 all, 1 words, 2 sentences
  @override
  Widget build(BuildContext context) => Watch((_) {
        final items = <MapEntry<int, W>>[];
        for (var lv = 0; lv < 5; lv++) {
          if (AppState.i.locked(lv)) continue;
          if (kind != 2) items.addAll(vocab[lv].map((w) => MapEntry(lv, w)));
          if (kind != 1) items.addAll(reading[lv].map((w) => MapEntry(lv, w)));
        }
        final f = q.trim().toLowerCase();
        final res = f.isEmpty ? items : items.where((e) => e.value.ko.contains(f) || e.value.rom.toLowerCase().contains(f) || e.value.tr.toLowerCase().contains(f)).toList();
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              onChanged: (v) => setState(() => q = v),
              decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: t('search'), filled: true, fillColor: KColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18))),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              for (final e in [[0, 'all'], [1, 'words'], [2, 'sentences']])
                Padding(padding: const EdgeInsetsDirectional.only(end: 8), child: ChoiceChip(label: Text(t(e[1] as String)), selected: kind == e[0], onSelected: (_) => setState(() => kind = e[0] as int))),
              const Spacer(),
              TextButton.icon(onPressed: () => openRoute(context, '/vocab'), icon: const Icon(Icons.style), label: Text(t('cardsStart'))),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: min(res.length, 300),
              itemBuilder: (c, i) {
                final e = res[i], w = e.value;
                final learned = Srs.box(w) >= 3;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    onTap: () => AppState.i.speak(w.ko),
                    child: KCard(padding: const EdgeInsets.all(12), child: Row(children: [
                      const Icon(Icons.volume_up, color: KColors.primary),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(w.ko, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                        Text(w.rom, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                        Text(w.tr, style: const TextStyle(color: KColors.primary, fontSize: 13)),
                      ])),
                      Column(children: [
                        Text(levelShort[e.key], style: const TextStyle(fontSize: 10, color: Colors.white54)),
                        Icon(learned ? Icons.star : Icons.star_border, color: KColors.gold, size: 20),
                      ]),
                    ])),
                  ),
                );
              },
            ),
          ),
        ]);
      });
}

// =================== TRAIN ===================
class TrainTab extends StatelessWidget {
  const TrainTab({super.key});
  @override
  Widget build(BuildContext context) => Watch((_) {
        final tiles = [
          [Icons.menu_book, KColors.primary, 'reading', '/reading'],
          [Icons.headphones, KColors.blue, 'listening', '/listening'],
          [Icons.record_voice_over, KColors.orange, 'pron', '/pronounce'],
          [Icons.forum, Colors.pinkAccent, 'chat', '/chat'],
          [Icons.style, KColors.green, 'vocab', '/vocab'],
          [Icons.sort, Colors.teal, 'builder', '/builder'],
          [Icons.edit_note, Colors.redAccent, 'notebook', '/notebook'],
          [Icons.school, Colors.indigoAccent, 'etiquette', '/etiquette'],
          [Icons.compare_arrows, Colors.deepPurpleAccent, 'drills', '/drill'],
        ];
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text(t('train'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 1.05,
            children: [
              for (final k in tiles)
                InkWell(
                  onTap: () => openRoute(context, k[3] as String),
                  child: Container(
                    decoration: BoxDecoration(color: k[1] as Color, borderRadius: BorderRadius.circular(18)),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(k[0] as IconData, color: Colors.white, size: 28),
                      const SizedBox(height: 4),
                      Text(t(k[2] as String), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          InkWell(
            onTap: () => Navigator.pushNamed(context, '/plan'),
            child: KCard(child: Row(children: [
              const Icon(Icons.flag, color: KColors.gold),
              const SizedBox(width: 10),
              Expanded(child: Text(t('plan'), style: const TextStyle(fontWeight: FontWeight.w800))),
              Text('${t('due')}: ${Srs.dueNow()}', style: const TextStyle(color: KColors.orange, fontSize: 12)),
            ])),
          ),
        ]);
      });
}

// =================== PROFILE (stats, culture, settings) ===================
class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  @override
  Widget build(BuildContext context) => Watch((_) {
        final u = Auth.user, s = AppState.i, lv = s.level;
        final comp = levelCompletion(lv);
        return ListView(padding: const EdgeInsets.all(16), children: [
          KCard(child: Row(children: [
            CircleAvatar(radius: 26, backgroundColor: KColors.primary, child: Text((u?.name ?? '?').isEmpty ? '?' : (u?.name ?? '?')[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 22))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(u?.name ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Text(u?.email ?? '', style: const TextStyle(color: Colors.white60, fontSize: 12)),
              if (s.premium) Text('${t('until')} ${s.until!.toLocal().toString().substring(0, 10)}', style: const TextStyle(color: KColors.gold, fontSize: 12)),
            ])),
          ])),
          const SizedBox(height: 12),
          KCard(child: Row(children: [
            SizedBox(
              width: 84, height: 84,
              child: Stack(alignment: Alignment.center, children: [
                SizedBox.expand(child: CircularProgressIndicator(value: comp, strokeWidth: 8, backgroundColor: Colors.white12, color: KColors.green)),
                Text('${(comp * 100).round()}%', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              ]),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('completion'), style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(t('lv$lv'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
              const SizedBox(height: 6),
              Text('${t('wordsLearned')}: ${Srs.learnedAll()}', style: const TextStyle(fontSize: 13)),
            ])),
          ])),
          const SizedBox(height: 10),
          Row(children: [
            _statTile(Icons.check_circle, KColors.gold, '${s.done}', t('done')),
            const SizedBox(width: 8),
            _statTile(Icons.local_fire_department, KColors.orange, '${s.streak}', t('streak')),
            const SizedBox(width: 8),
            _statTile(Icons.star, KColors.gold, '${s.xp}', t('points')),
          ]),
          const SizedBox(height: 10),
          KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('last7'), style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            _weekBars(s.weekXp()),
          ])),
          const SizedBox(height: 10),
          KCard(child: Row(children: [
            const Icon(Icons.place, color: KColors.gold, size: 30),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('place'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
              Text(places[lv][gLang], style: const TextStyle(fontWeight: FontWeight.w800)),
            ])),
          ])),
          for (final k in ['hangul', 'kimchi', 'respect'])
            Padding(padding: const EdgeInsets.only(top: 8), child: KCard(child: Text(t(k), style: const TextStyle(height: 1.6, fontSize: 13)))),
          const SizedBox(height: 10),
          ListTile(leading: const Icon(Icons.workspace_premium, color: KColors.gold), title: Text(t('premium')), onTap: () => goPaywall(context)),
          ListTile(leading: const Icon(Icons.swap_vert), title: Text(t('changeLevel')), onTap: () => Navigator.pushNamed(context, '/levels')),
          ListTile(leading: const Icon(Icons.rate_review_outlined), title: Text(t('feedback')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FeedbackScreen(level: s.level)))),
          Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: langChips()),
          ListTile(
            leading: const Icon(Icons.logout),
            title: Text(t('logout')),
            onTap: () async {
              await Auth.signOut();
              AppState.i.reset();
              if (context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
            title: Text(t('delete'), style: const TextStyle(color: Colors.redAccent)),
            onTap: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (d) => AlertDialog(
                  content: Text(t('sure')),
                  actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(t('cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(t('confirm')))],
                ),
              );
              if (ok == true) {
                try { await Auth.deleteAccount(); } catch (_) {}
                AppState.i.reset();
                if (context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
              }
            },
          ),
        ]);
      });
}
